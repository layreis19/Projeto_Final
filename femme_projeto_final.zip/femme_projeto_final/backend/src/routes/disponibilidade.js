const express = require('express');
const pool = require('../db');
const { autenticar, exigirTipo } = require('../middleware/auth');

const router = express.Router();
router.use(autenticar, exigirTipo('profissional'));

async function obterProfissionalId(utilizadorId) {
  const [rows] = await pool.query('SELECT id FROM profissionais WHERE utilizador_id = ?', [utilizadorId]);
  return rows[0] ? rows[0].id : null;
}

/**
 * @openapi
 * /profissional/disponibilidades:
 *   get:
 *     summary: Lista o horário semanal de atendimento da profissional
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Lista de disponibilidades }
 */
router.get('/disponibilidades', async (req, res) => {
  const profissionalId = await obterProfissionalId(req.utilizador.id);
  const [rows] = await pool.query(
    'SELECT id, dia_semana, hora_inicio, hora_fim FROM disponibilidades WHERE profissional_id = ? ORDER BY dia_semana, hora_inicio',
    [profissionalId]
  );
  res.json(rows);
});

/**
 * @openapi
 * /profissional/disponibilidades:
 *   post:
 *     summary: Adiciona um horário de atendimento (ex. Segunda 09:00-18:00)
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [dia_semana, hora_inicio, hora_fim]
 *             properties:
 *               dia_semana: { type: integer, minimum: 0, maximum: 6, description: "0=domingo ... 6=sábado" }
 *               hora_inicio: { type: string, example: "09:00" }
 *               hora_fim: { type: string, example: "18:00" }
 *     responses:
 *       201: { description: Horário adicionado }
 *       400: { description: Dados inválidos }
 */
router.post('/disponibilidades', async (req, res) => {
  const { dia_semana, hora_inicio, hora_fim } = req.body;
  if (dia_semana == null || !hora_inicio || !hora_fim) {
    return res.status(400).json({ erro: 'Preenche o dia da semana e o horário.' });
  }
  if (dia_semana < 0 || dia_semana > 6) return res.status(400).json({ erro: 'Dia da semana inválido.' });
  if (hora_fim <= hora_inicio) return res.status(400).json({ erro: 'A hora de fim tem de ser depois da hora de início.' });

  const profissionalId = await obterProfissionalId(req.utilizador.id);

  // Impede duplicados e sobreposições de horário no mesmo dia da semana
  // (ex.: já existe 09:00-18:00 e tenta adicionar 09:00-18:00 outra vez, ou 10:00-12:00 que fica lá dentro)
  const [conflitos] = await pool.query(
    `SELECT id FROM disponibilidades
     WHERE profissional_id = ? AND dia_semana = ?
       AND hora_inicio < ? AND hora_fim > ?`,
    [profissionalId, dia_semana, hora_fim, hora_inicio]
  );
  if (conflitos.length) {
    return res.status(409).json({ erro: 'Já existe um horário definido que sobrepõe este período nesse dia.' });
  }

  const [resultado] = await pool.query(
    'INSERT INTO disponibilidades (profissional_id, dia_semana, hora_inicio, hora_fim) VALUES (?, ?, ?, ?)',
    [profissionalId, dia_semana, hora_inicio, hora_fim]
  );
  res.status(201).json({ id: resultado.insertId });
});

/**
 * @openapi
 * /profissional/disponibilidades/{id}:
 *   delete:
 *     summary: Remove um horário de atendimento
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Horário removido }
 *       404: { description: Não encontrado }
 */
router.delete('/disponibilidades/:id', async (req, res) => {
  const profissionalId = await obterProfissionalId(req.utilizador.id);
  const [resultado] = await pool.query(
    'DELETE FROM disponibilidades WHERE id = ? AND profissional_id = ?',
    [req.params.id, profissionalId]
  );
  if (!resultado.affectedRows) return res.status(404).json({ erro: 'Horário não encontrado.' });
  res.json({ mensagem: 'Horário removido.' });
});

/**
 * @openapi
 * /profissional/bloqueios:
 *   get:
 *     summary: Lista os períodos bloqueados na agenda (ex. férias, folgas)
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Lista de bloqueios }
 */
router.get('/bloqueios', async (req, res) => {
  const profissionalId = await obterProfissionalId(req.utilizador.id);
  const [rows] = await pool.query(
    'SELECT id, data_inicio, data_fim, motivo FROM bloqueios_agenda WHERE profissional_id = ? ORDER BY data_inicio',
    [profissionalId]
  );
  res.json(rows);
});

/**
 * @openapi
 * /profissional/bloqueios:
 *   post:
 *     summary: Bloqueia um período na agenda (ex. férias)
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [data_inicio, data_fim]
 *             properties:
 *               data_inicio: { type: string, format: date-time }
 *               data_fim: { type: string, format: date-time }
 *               motivo: { type: string }
 *     responses:
 *       201: { description: Bloqueio criado }
 *       400: { description: Dados inválidos }
 */
router.post('/bloqueios', async (req, res) => {
  const { data_inicio, data_fim, motivo } = req.body;
  if (!data_inicio || !data_fim) return res.status(400).json({ erro: 'Escolhe a data de início e de fim.' });
  if (new Date(data_fim) <= new Date(data_inicio)) {
    return res.status(400).json({ erro: 'A data de fim tem de ser depois da data de início.' });
  }

  const profissionalId = await obterProfissionalId(req.utilizador.id);
  const [resultado] = await pool.query(
    'INSERT INTO bloqueios_agenda (profissional_id, data_inicio, data_fim, motivo) VALUES (?, ?, ?, ?)',
    [profissionalId, data_inicio, data_fim, motivo || null]
  );
  res.status(201).json({ id: resultado.insertId });
});

/**
 * @openapi
 * /profissional/bloqueios/{id}:
 *   delete:
 *     summary: Remove um bloqueio de agenda
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Bloqueio removido }
 *       404: { description: Não encontrado }
 */
router.delete('/bloqueios/:id', async (req, res) => {
  const profissionalId = await obterProfissionalId(req.utilizador.id);
  const [resultado] = await pool.query(
    'DELETE FROM bloqueios_agenda WHERE id = ? AND profissional_id = ?',
    [req.params.id, profissionalId]
  );
  if (!resultado.affectedRows) return res.status(404).json({ erro: 'Bloqueio não encontrado.' });
  res.json({ mensagem: 'Bloqueio removido.' });
});

module.exports = router;
