const express = require('express');
const path = require('path');
const multer = require('multer');
const pool = require('../db');
const { autenticar, exigirTipo } = require('../middleware/auth');
const { enviarEmail, modelos } = require('../email');
const { concluirMarcacoesPassadas } = require('../utils/concluirMarcacoes');

const router = express.Router();
router.use(autenticar, exigirTipo('profissional'));

// Devolve a linha da tabela `profissionais` associada ao utilizador autenticado.
async function obterProfissionalId(utilizadorId) {
  const [rows] = await pool.query('SELECT id FROM profissionais WHERE utilizador_id = ?', [utilizadorId]);
  return rows[0] ? rows[0].id : null;
}

/**
 * @openapi
 * /profissional/dashboard:
 *   get:
 *     summary: Indicadores resumo da profissional autenticada
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Indicadores do dashboard }
 */
router.get('/dashboard', async (req, res) => {
  // Antes de contar marcações ativas, atualiza pendentes cuja hora já passou
  // para "expirada" (senão continuariam a contar como ativas).
  await concluirMarcacoesPassadas();

  const profissionalId = await obterProfissionalId(req.utilizador.id);
  if (!profissionalId) return res.status(404).json({ erro: 'Perfil de profissional não encontrado.' });

  const [[perfil]] = await pool.query('SELECT estado_aprovacao FROM profissionais WHERE id = ?', [profissionalId]);
  const [[ativas]] = await pool.query(
    "SELECT COUNT(*) AS n FROM marcacoes WHERE profissional_id = ? AND estado IN ('pendente','confirmada')",
    [profissionalId]
  );
  const [[media]] = await pool.query(
    `SELECT ROUND(AVG(a.nota), 1) AS media FROM avaliacoes a
     JOIN marcacoes m ON m.id = a.marcacao_id
     WHERE m.profissional_id = ? AND a.estado = 'publicada'`,
    [profissionalId]
  );
  const [[publicadas]] = await pool.query(
    `SELECT COUNT(*) AS n FROM avaliacoes a JOIN marcacoes m ON m.id = a.marcacao_id
     WHERE m.profissional_id = ? AND a.estado = 'publicada'`,
    [profissionalId]
  );
  const [[porModerar]] = await pool.query(
    `SELECT COUNT(*) AS n FROM avaliacoes a JOIN marcacoes m ON m.id = a.marcacao_id
     WHERE m.profissional_id = ? AND a.estado = 'pendente'`,
    [profissionalId]
  );

  res.json({
    estado_perfil: perfil.estado_aprovacao,
    marcacoes_ativas: ativas.n,
    classificacao_media: media.media,
    total_avaliacoes: publicadas.n,
    avaliacoes_por_moderar: porModerar.n,
  });
});

/**
 * @openapi
 * /profissional/me:
 *   get:
 *     summary: Devolve o perfil da profissional autenticada
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Perfil da profissional }
 */
router.get('/me', async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM profissionais WHERE utilizador_id = ?', [req.utilizador.id]);
  if (!rows.length) return res.status(404).json({ erro: 'Perfil de profissional não encontrado.' });
  const p = rows[0];
  res.json({
    id: p.id,
    nome_negocio: p.nome_negocio,
    localizacao: p.localizacao,
    instagram: p.instagram,
    bio: p.descricao,
    id_categoria: p.categoria_id,
    foto_perfil: p.foto_perfil,
    foto_banner: p.foto_banner,
    estado_aprovacao: p.estado_aprovacao,
  });
});

/**
 * @openapi
 * /profissional/me:
 *   put:
 *     summary: Atualiza os dados da página pública da profissional (texto)
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               nome_negocio: { type: string }
 *               localizacao: { type: string }
 *               instagram: { type: string }
 *               bio: { type: string }
 *               id_categoria_principal: { type: integer }
 *     responses:
 *       200: { description: Perfil atualizado }
 */
router.put('/me', async (req, res) => {
  const { nome_negocio, localizacao, instagram, bio, id_categoria_principal } = req.body;
  await pool.query(
    `UPDATE profissionais SET nome_negocio = ?, localizacao = ?, instagram = ?, descricao = ?, categoria_id = ?
     WHERE utilizador_id = ?`,
    [nome_negocio, localizacao || null, instagram || null, bio || null, id_categoria_principal || null, req.utilizador.id]
  );
  res.json({ mensagem: 'Perfil atualizado.' });
});

// Upload de documentos (identificação / comprovativo de atividade) — pasta PRIVADA,
// nunca servida via express.static (só o admin acede, através da base de dados/disco).
const storageDocumentos = multer.diskStorage({
  destination: path.join(__dirname, '..', 'uploads', 'documentos'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.fieldname}${path.extname(file.originalname)}`),
});
const uploadDocumentos = multer({ storage: storageDocumentos, limits: { fileSize: 5 * 1024 * 1024 } });

/**
 * @openapi
 * /profissional/preview:
 *   get:
 *     summary: Devolve o perfil completo da profissional autenticada, tal como apareceria na página pública (serviços, disponibilidades, fotos) — funciona mesmo que a conta ainda esteja pendente/recusada, para permitir pré-visualização antes da aprovação do administrador.
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Perfil completo para pré-visualização }
 *       404: { description: Perfil de profissional não encontrado }
 */
router.get('/preview', async (req, res) => {
  const [rows] = await pool.query(
    `SELECT p.id, p.nome_negocio, p.descricao AS bio, p.instagram, p.localizacao,
            p.foto_perfil, p.foto_banner, p.estado_aprovacao, c.nome AS categoria,
            (SELECT ROUND(AVG(a.nota), 1) FROM avaliacoes a
               JOIN marcacoes m ON m.id = a.marcacao_id
               WHERE m.profissional_id = p.id AND a.estado = 'publicada') AS classificacao_media,
            (SELECT COUNT(*) FROM avaliacoes a
               JOIN marcacoes m ON m.id = a.marcacao_id
               WHERE m.profissional_id = p.id AND a.estado = 'publicada') AS total_avaliacoes
     FROM profissionais p
     LEFT JOIN categorias c ON c.id = p.categoria_id
     WHERE p.utilizador_id = ?`,
    [req.utilizador.id]
  );
  if (!rows.length) return res.status(404).json({ erro: 'Perfil de profissional não encontrado.' });

  const p = rows[0];
  const [servicos] = await pool.query(
    'SELECT id, nome, descricao, preco, duracao_minutos FROM servicos WHERE profissional_id = ? AND ativo = TRUE',
    [p.id]
  );
  const [disponibilidades] = await pool.query(
    'SELECT dia_semana, hora_inicio, hora_fim FROM disponibilidades WHERE profissional_id = ? ORDER BY dia_semana, hora_inicio',
    [p.id]
  );
  res.json({
    ...p,
    servicos: servicos.map((s) => ({ ...s, preco: s.preco != null ? Number(s.preco) : s.preco })),
    disponibilidades,
  });
});

/**
 * @openapi
 * /profissional/documentos:
 *   post:
 *     summary: Envia documentos de identificação/atividade para validação do admin
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               documento_identificacao: { type: string, format: binary }
 *               documento_atividade: { type: string, format: binary }
 *     responses:
 *       201: { description: Documentos recebidos }
 */
router.post(
  '/documentos',
  uploadDocumentos.fields([{ name: 'documento_identificacao', maxCount: 1 }, { name: 'documento_atividade', maxCount: 1 }]),
  async (req, res) => {
    const profissionalId = await obterProfissionalId(req.utilizador.id);
    if (!profissionalId) return res.status(404).json({ erro: 'Perfil de profissional não encontrado.' });

    const ficheiros = req.files || {};
    const tarefas = [];
    if (ficheiros.documento_identificacao) {
      tarefas.push(
        pool.query(
          "INSERT INTO profissional_documentos (profissional_id, tipo, caminho_ficheiro) VALUES (?, 'identificacao', ?)",
          [profissionalId, ficheiros.documento_identificacao[0].filename]
        )
      );
    }
    if (ficheiros.documento_atividade) {
      tarefas.push(
        pool.query(
          "INSERT INTO profissional_documentos (profissional_id, tipo, caminho_ficheiro) VALUES (?, 'comprovativo_atividade', ?)",
          [profissionalId, ficheiros.documento_atividade[0].filename]
        )
      );
    }
    if (!tarefas.length) return res.status(400).json({ erro: 'Nenhum ficheiro recebido.' });

    await Promise.all(tarefas);
    res.status(201).json({ mensagem: 'Documentos recebidos. Aguarda validação do administrador.' });
  }
);

// Upload de imagens de personalização (foto de perfil / banner) — pasta PÚBLICA,
// servida em /uploads pelo app.js, para poderem ser mostradas na página pública da profissional.
const storageImagens = multer.diskStorage({
  destination: path.join(__dirname, '..', 'uploads', 'imagens'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.fieldname}${path.extname(file.originalname)}`),
});
const filtroImagem = (req, file, cb) => {
  const permitido = ['image/jpeg', 'image/png', 'image/webp'].includes(file.mimetype);
  if (!permitido) {
    const erro = new Error('Só são aceites imagens JPG, PNG ou WEBP.');
    erro.status = 400;
    return cb(erro);
  }
  cb(null, true);
};
const uploadImagens = multer({
  storage: storageImagens,
  fileFilter: filtroImagem,
  limits: { fileSize: 4 * 1024 * 1024 },
});

/**
 * @openapi
 * /profissional/imagens:
 *   post:
 *     summary: Envia/atualiza a foto de perfil e/ou o banner da página pública da profissional
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               foto_perfil: { type: string, format: binary }
 *               foto_banner: { type: string, format: binary }
 *     responses:
 *       200: { description: Imagens atualizadas, devolve os novos caminhos públicos }
 */
router.post('/imagens', uploadImagens.fields([{ name: 'foto_perfil', maxCount: 1 }, { name: 'foto_banner', maxCount: 1 }]), async (req, res) => {
  const profissionalId = await obterProfissionalId(req.utilizador.id);
  if (!profissionalId) return res.status(404).json({ erro: 'Perfil de profissional não encontrado.' });

  const ficheiros = req.files || {};
  if (!ficheiros.foto_perfil && !ficheiros.foto_banner) {
    return res.status(400).json({ erro: 'Escolhe pelo menos uma imagem.' });
  }

  const campos = [];
  const valores = [];
  if (ficheiros.foto_perfil) {
    campos.push('foto_perfil = ?');
    valores.push(`/uploads/${ficheiros.foto_perfil[0].filename}`);
  }
  if (ficheiros.foto_banner) {
    campos.push('foto_banner = ?');
    valores.push(`/uploads/${ficheiros.foto_banner[0].filename}`);
  }
  valores.push(profissionalId);

  await pool.query(`UPDATE profissionais SET ${campos.join(', ')} WHERE id = ?`, valores);

  const [[atualizado]] = await pool.query('SELECT foto_perfil, foto_banner FROM profissionais WHERE id = ?', [
    profissionalId,
  ]);
  res.json({ mensagem: 'Imagens atualizadas.', ...atualizado });
});

/**
 * @openapi
 * /profissional/servicos:
 *   get:
 *     summary: Lista os serviços (ativos e inativos) da profissional autenticada
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Lista de serviços }
 */
router.get('/servicos', async (req, res) => {
  const profissionalId = await obterProfissionalId(req.utilizador.id);
  const [rows] = await pool.query(
    'SELECT id, nome, descricao, preco, duracao_minutos, ativo FROM servicos WHERE profissional_id = ? ORDER BY nome',
    [profissionalId]
  );
  res.json(rows.map((r) => ({ ...r, preco: Number(r.preco) })));
});

/**
 * @openapi
 * /profissional/servicos:
 *   post:
 *     summary: Cria um novo serviço
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [nome, duracao_minutos, preco]
 *             properties:
 *               nome: { type: string }
 *               descricao: { type: string }
 *               duracao_minutos: { type: integer }
 *               preco: { type: number }
 *     responses:
 *       201: { description: Serviço criado }
 */
router.post('/servicos', async (req, res) => {
  // Nota: o formulário do frontend também envia `id_categoria`, mas no modelo de dados
  // a categoria pertence à profissional (profissionais.categoria_id), não ao serviço —
  // por isso este campo é aceite e ignorado aqui.
  const profissionalId = await obterProfissionalId(req.utilizador.id);
  if (!profissionalId) return res.status(404).json({ erro: 'Perfil de profissional não encontrado.' });

  const { nome, duracao_minutos, preco, descricao } = req.body;
  if (!nome || !duracao_minutos || preco == null) {
    return res.status(400).json({ erro: 'Preenche nome, duração e preço do serviço.' });
  }

  const [resultado] = await pool.query(
    'INSERT INTO servicos (profissional_id, nome, descricao, preco, duracao_minutos) VALUES (?, ?, ?, ?, ?)',
    [profissionalId, nome, descricao || null, preco, duracao_minutos]
  );
  res.status(201).json({ id: resultado.insertId });
});

/**
 * @openapi
 * /profissional/servicos/{id}:
 *   delete:
 *     summary: Desativa um serviço (soft delete)
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Serviço desativado }
 *       404: { description: Serviço não encontrado }
 */
router.delete('/servicos/:id', async (req, res) => {
  const profissionalId = await obterProfissionalId(req.utilizador.id);
  const [resultado] = await pool.query(
    'UPDATE servicos SET ativo = FALSE WHERE id = ? AND profissional_id = ?',
    [req.params.id, profissionalId]
  );
  if (!resultado.affectedRows) return res.status(404).json({ erro: 'Serviço não encontrado.' });
  res.json({ mensagem: 'Serviço desativado.' });
});

/**
 * @openapi
 * /profissional/marcacoes:
 *   get:
 *     summary: Lista as marcações da profissional autenticada
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: estado
 *         schema: { type: string, enum: [pendente, confirmada, recusada, cancelada, concluida, expirada] }
 *     responses:
 *       200: { description: Lista de marcações }
 */
router.get('/marcacoes', async (req, res) => {
  // Antes de listar, atualiza marcações "confirmada" cuja hora já passou para "concluida".
  await concluirMarcacoesPassadas();

  const profissionalId = await obterProfissionalId(req.utilizador.id);
  const { estado } = req.query;
  const condicoes = ['m.profissional_id = ?'];
  const params = [profissionalId];
  if (estado) {
    condicoes.push('m.estado = ?');
    params.push(estado);
  }

  const [rows] = await pool.query(
    `SELECT m.id, m.data_hora, m.preco_no_momento, m.duracao_no_momento, m.estado,
            s.nome AS servico_nome, u.nome AS cliente_nome
     FROM marcacoes m
     JOIN servicos s ON s.id = m.servico_id
     JOIN utilizadores u ON u.id = m.cliente_id
     WHERE ${condicoes.join(' AND ')}
     ORDER BY m.data_hora ASC`,
    params
  );
  res.json(rows);
});

/**
 * @openapi
 * /profissional/marcacoes/{id}/estado:
 *   put:
 *     summary: Muda o estado de uma marcação (confirmar, recusar, concluir, cancelar)
 *     tags: [Profissional]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [estado]
 *             properties:
 *               estado: { type: string, enum: [confirmada, recusada, concluida, cancelada] }
 *     responses:
 *       200: { description: Estado atualizado }
 *       400: { description: Estado inválido, ou pedido já não está pendente (por exemplo, expirou) }
 *       404: { description: Marcação não encontrada }
 */
const ESTADOS_PERMITIDOS = ['confirmada', 'recusada', 'concluida', 'cancelada'];
const ROTULOS_ESTADO_EMAIL = { confirmada: 'confirmada', recusada: 'recusada', concluida: 'concluída', cancelada: 'cancelada' };
router.put('/marcacoes/:id/estado', async (req, res) => {
  const { estado } = req.body;
  if (!ESTADOS_PERMITIDOS.includes(estado)) return res.status(400).json({ erro: 'Estado inválido.' });

  // Atualiza primeiro pendentes cuja hora já passou para "expirada", para que
  // a verificação abaixo não deixe aceitar/recusar um pedido cujo horário já lá vai.
  await concluirMarcacoesPassadas();

  const profissionalId = await obterProfissionalId(req.utilizador.id);

  const [[atual]] = await pool.query(
    'SELECT estado FROM marcacoes WHERE id = ? AND profissional_id = ?',
    [req.params.id, profissionalId]
  );
  if (!atual) return res.status(404).json({ erro: 'Marcação não encontrada.' });

  if (['confirmada', 'recusada'].includes(estado) && atual.estado !== 'pendente') {
    return res.status(400).json({
      erro: atual.estado === 'expirada'
        ? 'Este pedido expirou porque a data e hora já passaram — já não pode ser aceite nem recusado.'
        : 'Este pedido já não está pendente.',
    });
  }

  const [resultado] = await pool.query(
    'UPDATE marcacoes SET estado = ? WHERE id = ? AND profissional_id = ?',
    [estado, req.params.id, profissionalId]
  );
  if (!resultado.affectedRows) return res.status(404).json({ erro: 'Marcação não encontrada.' });

  const [[detalhe]] = await pool.query(
    `SELECT m.data_hora, s.nome AS servico_nome, u.id AS cliente_id, u.nome AS cliente_nome, u.email AS cliente_email
     FROM marcacoes m
     JOIN servicos s ON s.id = m.servico_id
     JOIN utilizadores u ON u.id = m.cliente_id
     WHERE m.id = ?`,
    [req.params.id]
  );
  await pool.query(
    "INSERT INTO notificacoes (utilizador_id, tipo, mensagem) VALUES (?, 'marcacao', ?)",
    [detalhe.cliente_id, `O estado da tua marcação mudou para: ${estado}.`]
  );

  const dataFormatada = new Date(detalhe.data_hora).toLocaleString('pt-PT', { dateStyle: 'medium', timeStyle: 'short' });
  enviarEmail({
    to: detalhe.cliente_email,
    ...modelos.estadoMarcacaoParaCliente(detalhe.cliente_nome, detalhe.servico_nome, dataFormatada, ROTULOS_ESTADO_EMAIL[estado]),
  });

  res.json({ mensagem: 'Estado da marcação atualizado.' });
});

module.exports = router;
