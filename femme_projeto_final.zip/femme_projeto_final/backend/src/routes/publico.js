const express = require('express');
const pool = require('../db');
const { autenticar } = require('../middleware/auth');

const router = express.Router();
// Estas rotas deixaram de ser públicas: só o index.html (que não chama a API) é público.
// Passam a exigir sessão iniciada — qualquer tipo de utilizador (cliente, profissional ou admin).
router.use(autenticar);

// Normaliza os campos DECIMAL do mysql2 (vêm como string) para Number.
function paraNumero(servico) {
  return { ...servico, preco: servico.preco != null ? Number(servico.preco) : servico.preco };
}

/**
 * @openapi
 * /categorias:
 *   get:
 *     summary: Lista todas as categorias de serviços
 *     tags: [Descoberta]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Lista de categorias }
 *       401: { description: Sessão não iniciada ou inválida }
 */
router.get('/categorias', async (req, res) => {
  const [rows] = await pool.query('SELECT id, nome FROM categorias ORDER BY nome');
  res.json(rows);
});

/**
 * @openapi
 * /profissionais:
 *   get:
 *     summary: Pesquisa profissionais aprovadas (por nome/categoria/localização)
 *     tags: [Descoberta]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *       - in: query
 *         name: categoria
 *         schema: { type: integer }
 *       - in: query
 *         name: localizacao
 *         schema: { type: string }
 *         description: Filtra por zona/cidade (pesquisa parcial, sem distinguir maiúsculas)
 *     responses:
 *       200: { description: Lista de profissionais }
 *       401: { description: Sessão não iniciada ou inválida }
 */
router.get('/profissionais', async (req, res) => {
  const { q, categoria, localizacao } = req.query;
  const condicoes = ["p.estado_aprovacao = 'aprovado'", "u.estado = 'ativo'"];
  const params = [];

  if (q) {
    condicoes.push('(p.nome_negocio LIKE ? OR c.nome LIKE ?)');
    params.push(`%${q}%`, `%${q}%`);
  }
  if (categoria) {
    condicoes.push('p.categoria_id = ?');
    params.push(categoria);
  }
  if (localizacao) {
    condicoes.push('p.localizacao LIKE ?');
    params.push(`%${localizacao}%`);
  }

  const [rows] = await pool.query(
    `SELECT p.id, p.nome_negocio, p.localizacao, p.foto_perfil, c.nome AS categoria,
            (SELECT ROUND(AVG(a.nota), 1) FROM avaliacoes a
               JOIN marcacoes m ON m.id = a.marcacao_id
               WHERE m.profissional_id = p.id AND a.estado = 'publicada') AS classificacao_media,
            (SELECT COUNT(*) FROM avaliacoes a
               JOIN marcacoes m ON m.id = a.marcacao_id
               WHERE m.profissional_id = p.id AND a.estado = 'publicada') AS total_avaliacoes
     FROM profissionais p
     JOIN utilizadores u ON u.id = p.utilizador_id
     LEFT JOIN categorias c ON c.id = p.categoria_id
     WHERE ${condicoes.join(' AND ')}
     ORDER BY p.nome_negocio`,
    params
  );
  res.json(rows);
});

/**
 * @openapi
 * /profissionais/{id}:
 *   get:
 *     summary: Página pública de uma profissional (perfil, serviços, fotos)
 *     tags: [Descoberta]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Perfil da profissional }
 *       401: { description: Sessão não iniciada ou inválida }
 *       404: { description: Profissional não encontrada }
 */
router.get('/profissionais/:id', async (req, res) => {
  const [rows] = await pool.query(
    `SELECT p.id, p.nome_negocio, p.descricao AS bio, p.instagram, p.localizacao,
            p.foto_perfil, p.foto_banner, c.nome AS categoria,
            (SELECT ROUND(AVG(a.nota), 1) FROM avaliacoes a
               JOIN marcacoes m ON m.id = a.marcacao_id
               WHERE m.profissional_id = p.id AND a.estado = 'publicada') AS classificacao_media,
            (SELECT COUNT(*) FROM avaliacoes a
               JOIN marcacoes m ON m.id = a.marcacao_id
               WHERE m.profissional_id = p.id AND a.estado = 'publicada') AS total_avaliacoes
     FROM profissionais p
     LEFT JOIN categorias c ON c.id = p.categoria_id
     WHERE p.id = ? AND p.estado_aprovacao = 'aprovado'`,
    [req.params.id]
  );
  if (!rows.length) return res.status(404).json({ erro: 'Profissional não encontrada.' });

  const [servicos] = await pool.query(
    'SELECT id, nome, descricao, preco, duracao_minutos FROM servicos WHERE profissional_id = ? AND ativo = TRUE',
    [req.params.id]
  );
  const [disponibilidades] = await pool.query(
    'SELECT dia_semana, hora_inicio, hora_fim FROM disponibilidades WHERE profissional_id = ? ORDER BY dia_semana, hora_inicio',
    [req.params.id]
  );
  res.json({ ...rows[0], servicos: servicos.map(paraNumero), disponibilidades });
});

/**
 * @openapi
 * /profissionais/{id}/avaliacoes:
 *   get:
 *     summary: Lista as avaliações publicadas de uma profissional
 *     tags: [Descoberta]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Lista de avaliações publicadas }
 *       401: { description: Sessão não iniciada ou inválida }
 */
router.get('/profissionais/:id/avaliacoes', async (req, res) => {
  const [rows] = await pool.query(
    `SELECT a.id, a.nota AS classificacao, a.comentario, a.criado_em, u.nome AS cliente_nome
     FROM avaliacoes a
     JOIN marcacoes m ON m.id = a.marcacao_id
     JOIN utilizadores u ON u.id = m.cliente_id
     WHERE m.profissional_id = ? AND a.estado = 'publicada'
     ORDER BY a.criado_em DESC`,
    [req.params.id]
  );
  res.json(rows);
});

/**
 * @openapi
 * /servicos/{id}:
 *   get:
 *     summary: Detalhe público de um serviço
 *     tags: [Descoberta]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Detalhe do serviço }
 *       401: { description: Sessão não iniciada ou inválida }
 *       404: { description: Serviço não encontrado }
 */
router.get('/servicos/:id', async (req, res) => {
  const [rows] = await pool.query(
    `SELECT s.id, s.nome, s.descricao, s.preco, s.duracao_minutos, p.id AS profissional_id, p.nome_negocio AS profissional_nome
     FROM servicos s
     JOIN profissionais p ON p.id = s.profissional_id
     WHERE s.id = ? AND s.ativo = TRUE`,
    [req.params.id]
  );
  if (!rows.length) return res.status(404).json({ erro: 'Serviço não encontrado.' });
  res.json(paraNumero(rows[0]));
});

// Converte "HH:MM:SS" (ou "HH:MM") em minutos desde a meia-noite.
function paraMinutos(horaStr) {
  const [h, m] = horaStr.split(':').map(Number);
  return h * 60 + m;
}

// Combina uma data (só o dia interessa) com um nº de minutos desde a meia-noite, no fuso local.
function combinarDataMinutos(dataBase, minutosDoDia) {
  const d = new Date(dataBase);
  d.setHours(0, 0, 0, 0);
  d.setMinutes(minutosDoDia);
  return d;
}

function paraHHMM(minutosDoDia) {
  const h = String(Math.floor(minutosDoDia / 60)).padStart(2, '0');
  const m = String(minutosDoDia % 60).padStart(2, '0');
  return `${h}:${m}`;
}

const PASSO_MINUTOS = 15; // granularidade dos horários sugeridos ao cliente

/**
 * @openapi
 * /servicos/{id}/horarios:
 *   get:
 *     summary: Lista os horários de início disponíveis para um serviço, num dado dia
 *     description: >
 *       Calcula os horários possíveis com base no horário semanal de atendimento da
 *       profissional, excluindo bloqueios de agenda e marcações já existentes
 *       (pendentes ou confirmadas), e a duração do serviço. Só é possível marcar
 *       nestes horários — evita que o cliente escolha uma hora arbitrária.
 *     tags: [Descoberta]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *       - in: query
 *         name: data
 *         required: true
 *         schema: { type: string, format: date, example: "2026-08-10" }
 *     responses:
 *       200: { description: Lista de horários "HH:MM" disponíveis nesse dia }
 *       400: { description: Data em falta ou inválida }
 *       401: { description: Sessão não iniciada ou inválida }
 *       404: { description: Serviço não encontrado }
 */
router.get('/servicos/:id/horarios', async (req, res) => {
  const { data } = req.query;
  if (!data || !/^\d{4}-\d{2}-\d{2}$/.test(data)) {
    return res.status(400).json({ erro: 'Indica uma data no formato AAAA-MM-DD.' });
  }

  const [servicoRows] = await pool.query(
    'SELECT id, profissional_id, duracao_minutos FROM servicos WHERE id = ? AND ativo = TRUE',
    [req.params.id]
  );
  const servico = servicoRows[0];
  if (!servico) return res.status(404).json({ erro: 'Serviço não encontrado.' });

  const diaBase = new Date(`${data}T00:00:00`);
  if (Number.isNaN(diaBase.getTime())) return res.status(400).json({ erro: 'Data inválida.' });

  const inicioDoDia = new Date(diaBase);
  const fimDoDia = new Date(diaBase);
  fimDoDia.setDate(fimDoDia.getDate() + 1);

  // Não faz sentido devolver horários para um dia que já passou por completo.
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  if (inicioDoDia < hoje) return res.json({ horarios: [] });

  const diaSemana = diaBase.getDay(); // 0=domingo ... 6=sábado

  const [disponibilidades] = await pool.query(
    'SELECT hora_inicio, hora_fim FROM disponibilidades WHERE profissional_id = ? AND dia_semana = ?',
    [servico.profissional_id, diaSemana]
  );
  if (!disponibilidades.length) return res.json({ horarios: [] });

  const [bloqueios] = await pool.query(
    'SELECT data_inicio, data_fim FROM bloqueios_agenda WHERE profissional_id = ? AND data_inicio < ? AND data_fim > ?',
    [servico.profissional_id, fimDoDia, inicioDoDia]
  );

  const [marcacoesExistentes] = await pool.query(
    `SELECT data_hora, duracao_no_momento FROM marcacoes
     WHERE profissional_id = ? AND estado IN ('pendente', 'confirmada')
       AND data_hora >= ? AND data_hora < ?`,
    [servico.profissional_id, inicioDoDia, fimDoDia]
  );

  const ocupados = [
    ...bloqueios.map(b => ({ inicio: new Date(b.data_inicio), fim: new Date(b.data_fim) })),
    ...marcacoesExistentes.map(m => ({
      inicio: new Date(m.data_hora),
      fim: new Date(new Date(m.data_hora).getTime() + m.duracao_no_momento * 60000),
    })),
  ];

  const agora = new Date();
  const horariosDisponiveis = new Set();

  for (const janela of disponibilidades) {
    const inicioJanela = paraMinutos(janela.hora_inicio);
    const fimJanela = paraMinutos(janela.hora_fim);

    for (let minuto = inicioJanela; minuto + servico.duracao_minutos <= fimJanela; minuto += PASSO_MINUTOS) {
      const candidatoInicio = combinarDataMinutos(diaBase, minuto);
      const candidatoFim = new Date(candidatoInicio.getTime() + servico.duracao_minutos * 60000);

      if (candidatoInicio <= agora) continue; // não pode ser no passado
      const emConflito = ocupados.some(o => candidatoInicio < o.fim && o.inicio < candidatoFim);
      if (emConflito) continue;

      horariosDisponiveis.add(paraHHMM(minuto));
    }
  }

  res.json({ horarios: [...horariosDisponiveis].sort() });
});

module.exports = router;
