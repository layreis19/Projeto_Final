const pool = require('../db');

/**
 * Verificação "preguiçosa" (lazy check) do estado das marcações.
 *
 * Em vez de depender de um cron job ou de uma ação manual da profissional,
 * sempre que alguém consulta marcações (agenda da profissional, lista do
 * cliente, ou o próprio pedido de avaliação) corremos primeiro estes UPDATEs:
 *
 *  - qualquer marcação que estava "confirmada" e cuja data/hora já passou
 *    transita automaticamente para "concluida". Isto garante que o cliente
 *    consegue sempre avaliar um serviço que já aconteceu, sem exigir que a
 *    profissional se lembre de marcar a marcação como concluída manualmente.
 *
 *  - qualquer marcação que ainda estava "pendente" (a profissional nunca
 *    chegou a aceitar nem a recusar) e cuja data/hora já passou transita
 *    automaticamente para "expirada". Isto evita que a profissional continue
 *    a poder aceitar/recusar, ou que a cliente continue a poder cancelar, um
 *    pedido para um horário que já não existe.
 */
async function concluirMarcacoesPassadas() {
  await pool.query(
    "UPDATE marcacoes SET estado = 'concluida' WHERE estado = 'confirmada' AND data_hora < NOW()"
  );
  await pool.query(
    "UPDATE marcacoes SET estado = 'expirada' WHERE estado = 'pendente' AND data_hora < NOW()"
  );
}

module.exports = { concluirMarcacoesPassadas };
