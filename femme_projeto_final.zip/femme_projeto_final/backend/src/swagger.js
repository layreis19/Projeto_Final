const swaggerJsdoc = require('swagger-jsdoc');
const path = require('path');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Femme API',
      version: '1.0.0',
      description:
        'API do Femme/BloomBook — marketplace de marcação de serviços de beleza. ' +
        'Todas as rotas exigem o cabeçalho `Authorization: Bearer <token>` obtido em ' +
        '/auth/login ou /auth/registo (exceto as de autenticação/registo em si).',
    },
    servers: [{ url: '/api', description: 'Servidor atual' }],
    components: {
      securitySchemes: {
        bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' },
      },
    },
    tags: [
      { name: 'Autenticação' },
      { name: 'Descoberta' },
      { name: 'Marcações' },
      { name: 'Avaliações' },
      { name: 'Favoritos' },
      { name: 'Notificações' },
      { name: 'Profissional' },
      { name: 'Admin' },
    ],
  },
  // Lê os comentários @openapi diretamente dos ficheiros de rotas (caminho absoluto,
  // para funcionar independentemente do diretório a partir do qual o processo arranca).
   apis: [ path.join(__dirname, 'routes', '*.js').replace(/\\/g, '/'),],
};

module.exports = swaggerJsdoc(options);
