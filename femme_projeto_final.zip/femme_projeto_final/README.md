Femme

Marketplace web de marcação de serviços de beleza e bem-estar, que liga clientes a profissionais, com moderação de perfis e avaliações por um administrador.

Stack tecnológico
Camada	Tecnologia
Frontend	HTML + CSS (Bootstrap 5) + JavaScript puro (sem framework)
Backend	Node.js + Express (API REST)
Base de dados	MySQL / MariaDB
Autenticação	JWT
Documentação da API	Swagger (/api-docs)
Email	Nodemailer (recuperação de palavra-passe)
Estrutura do projeto
femme_projeto/
├── femme_schema.sql          → script de criação da base de dados (tabelas, triggers, dados de demo)
├── backend/
│   ├── .env                  → configuração local (BD, JWT, SMTP) — não subir para repositórios públicos
│   ├── package.json
│   └── src/
│       ├── app.js            → ponto de entrada, monta as rotas e o Swagger
│       ├── db.js             → pool de ligação MySQL
│       ├── email.js          → envio de emails (recuperação de password)
│       ├── middleware/       → autenticação JWT (auth.js)
│       ├── routes/           → um ficheiro por área (auth, público, cliente, profissional, admin, ...)
│       └── uploads/          → ficheiros enviados (fotos de perfil, documentos de aprovação)
└── frontend/
    ├── index.html            → página pública de apresentação (landing) — não exige sessão
    ├── registo.html          → registo de conta (cliente ou profissional, com upload de documentos)
    ├── recuperar-password.html / redefinir-password.html
    ├── css/style.css         → identidade visual (bordô / verde-azeitona / dourado, tipografia Fraunces)
    ├── js/api.js             → fetch da API, gestão de sessão (JWT), helpers de UI
    ├── cliente/               → área autenticada do cliente
    │   ├── login.html
    │   ├── descobrir.html    → pesquisa de profissionais (antiga página inicial)
    │   ├── perfil.html       → perfil público de uma profissional
    │   ├── marcar.html, agenda.html, mensagens.html, favoritos.html, notificacoes.html, conta.html
    ├── profissional/          → área autenticada da profissional
    │   ├── login.html, dashboard.html, pagina.html, servicos.html, disponibilidade.html,
    │   │   pedidos.html, agenda.html, mensagens.html, avaliacoes.html, notificacoes.html, pre-visualizacao.html
    └── admin/                 → área de administração
        ├── login.html, aprovacoes.html, utilizadores.html, avaliacoes.html

As pastas cliente/, profissional/ e admin/ seguem a mesma lógica: cada uma tem o seu próprio login.html e as suas páginas internas ligam-se entre si por caminhos relativos; para sair da pasta (ex. voltar à landing pública ou trocar de tipo de conta) usa-se ../.

Como correr o projeto localmente
1. Base de dados
bash
mysql -u root -p --default-character-set=utf8mb4 -e "CREATE DATABASE femme CHARACTER SET utf8mb4;"
mysql -u root -p --default-character-set=utf8mb4 femme < femme_schema.sql

⚠️ O --default-character-set=utf8mb4 é importante — sem isto os acentos ficam corrompidos.

2. Backend
bash
cd backend
npm install
npm install nodemailer
npm start        # ou: npm run dev (reinicia sozinho ao gravar ficheiros)

Confirma o ficheiro .env antes de arrancar (já vem preenchido para uma instalação local típica):

PORT=3000
DB_HOST="localhost"
DB_PORT=3306
DB_USER="root"
DB_PASSWORD=""
DB_NAME="femme"
JWT_SECRET="1234"
API disponível em http://localhost:3000/api
Documentação Swagger em http://localhost:3000/api-docs
O envio de email (recuperação de password) é opcional — sem SMTP_* configurado, o link fica só escrito na consola do servidor em modo de desenvolvimento.
3. Frontend

Basta servir a pasta frontend/ com qualquer servidor estático (não pode ser aberto em file:// por causa dos pedidos fetch):

bash
cd frontend
python -m http.server 8080

Abre http://localhost:8080/index.html.

Contas de demonstração
Email	Password	Tipo
admin@femme.pt	admin123	admin
ines.marques@femme.pt	profissional123	profissional (aprovada, já com horário)
rita.esteves@femme.pt	profissional123	profissional (pendente de aprovação)
ana.costa@femme.pt	cliente123	cliente
Regras de negócio principais
Sem interação sem conta. A landing pública (index.html) só apresenta a proposta da plataforma; pesquisar, marcar, avaliar ou trocar mensagens exige sempre login.
Perfis de profissional sujeitos a aprovação. No registo, quem escolhe "profissional" tem de submeter documento de identificação e comprovativo de atividade; a conta fica pendente até um admin aprovar.
Avaliações restritas. Só pode avaliar quem teve uma marcação concluída com essa profissional, e as avaliações passam por moderação do admin antes de ficarem públicas.
Marcações concluídas automaticamente. Uma marcação confirmada passa a concluída sozinha assim que a sua data/hora já passou — não depende de a profissional clicar em lado nenhum. É uma verificação "preguiçosa" (lazy check, ver backend/src/utils/concluirMarcacoes.js): sempre que se consulta a lista de marcações (do cliente ou da profissional) ou se tenta submeter uma avaliação, corre-se primeiro um UPDATE que fecha as marcações confirmadas cuja hora já passou. Garante que o cliente consegue sempre avaliar, sem exigir um passo manual extra.
Só é possível marcar em horários realmente disponíveis. Ao marcar um serviço, o cliente escolhe apenas entre os horários que a API calcula como livres nesse dia (GET /servicos/:id/horarios) — a partir do horário semanal de atendimento da profissional, dos bloqueios de agenda (férias, folgas) e das marcações já existentes. Não é possível submeter uma data/hora arbitrária a partir do frontend.
Mensagens ligadas a marcações. Não há chat livre — a conversa fica sempre associada a uma marcação existente.
Login social (Google, etc.) é permitido apenas para clientes; nesse caso a conta pode não ter password_hash.
Eliminação de conta é sempre soft-delete (campo estado), nunca remoção definitiva da linha na base de dados.
Endpoints principais da API

Base: http://localhost:3000/api

Área	Prefixo	Exemplos
Autenticação	/auth	POST /registo, POST /login, POST /recuperar-password, POST /redefinir-password
Público (sem login)	/	GET /categorias, GET /profissionais, GET /profissionais/:id, GET /servicos/:id, GET /servicos/:id/horarios?data=AAAA-MM-DD
Cliente	/cliente	GET /me, PUT /me, PUT /password
Marcações	/marcacoes	POST /, GET /minhas, PUT /:id/cancelar, GET /conversas, GET /:id/mensagens
Favoritos	/favoritos	GET /, POST /:profissionalId, DELETE /:profissionalId
Notificações	/notificacoes	GET /, PUT /:id/lida, PUT /lidas
Avaliações	/avaliacoes	POST /
Profissional	/profissional	GET /dashboard, GET/PUT /me, POST /documentos, GET/POST /servicos, GET /marcacoes, PUT /marcacoes/:id/estado
Disponibilidade	/profissional	GET/POST/DELETE /disponibilidades, GET/POST/DELETE /bloqueios
Admin	/admin	GET /aprovacoes, PUT /profissionais/:id/aprovar, GET /utilizadores, GET /avaliacoes

A lista completa, com parâmetros e exemplos de resposta, está no Swagger (/api-docs).

Notas para produção
Gerar um JWT_SECRET novo e forte, e não o versionar em Git.
Configurar um SMTP real (o atual usa uma password de aplicação de demonstração — substituir antes de qualquer deployment real).
A pasta backend/src/uploads/ guarda ficheiros em disco local; em produção deve passar para armazenamento persistente (ex. bucket).
Limitações conhecidas
Não é possível reagendar uma marcação existente (só cancelar e criar uma nova).
A candidatura a profissional não tem ainda um passo de reenvio de documentos caso sejam rejeitados no primeiro registo — é preciso contactar o admin.
