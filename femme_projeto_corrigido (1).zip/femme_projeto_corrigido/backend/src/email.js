const nodemailer = require('nodemailer');

const SMTP_CONFIGURADO = !!(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);

let transporter = null;
if (SMTP_CONFIGURADO) {
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT) || 587,
    secure: Number(process.env.SMTP_PORT) === 465,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
}

/**
 * Envia um email. Se o SMTP não estiver configurado no .env (SMTP_HOST/SMTP_USER/SMTP_PASS),
 * fica em "modo de desenvolvimento": em vez de falhar, escreve o email na consola.
 * Isto permite correr o projeto localmente sem precisar logo de uma conta SMTP real.
 */
async function enviarEmail({ to, subject, html }) {
  if (!to) return; // sem email de destino (ex.: conta antiga sem email válido) — ignora silenciosamente

  if (!SMTP_CONFIGURADO) {
    console.log(`\n[EMAIL — modo consola, sem SMTP configurado]\nPara: ${to}\nAssunto: ${subject}\n${html}\n`);
    return;
  }

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_FROM || '"Femme" <no-reply@femme.pt>',
      to,
      subject,
      html,
    });
    console.log(`Email enviado para ${to} com sucesso (assunto: "${subject}")`);
  } catch (e) {
    // Um email falhado nunca deve rebentar o pedido do utilizador (a marcação já foi
    // criada/atualizada com sucesso) — só regista o erro.
    console.error('Erro ao enviar email:', e.message);
  }
}

const modelos = {
  novaMarcacaoParaProfissional: (nomeProfissional, nomeCliente, servico, dataHora) => ({
    subject: 'Femme — Novo pedido de marcação',
    html: `<p>Olá ${nomeProfissional},</p>
      <p><strong>${nomeCliente}</strong> pediu uma marcação para <strong>${servico}</strong> em
      <strong>${dataHora}</strong>.</p>
      <p>Entra na tua área de profissional para aceitar ou recusar o pedido.</p>`,
  }),
  estadoMarcacaoParaCliente: (nomeCliente, servico, dataHora, estado) => ({
    subject: `Femme — A tua marcação foi ${estado}`,
    html: `<p>Olá ${nomeCliente},</p>
      <p>A tua marcação de <strong>${servico}</strong> em <strong>${dataHora}</strong> foi
      <strong>${estado}</strong>.</p>`,
  }),
  cancelamento: (nome, servico, dataHora) => ({
    subject: 'Femme — Marcação cancelada',
    html: `<p>Olá ${nome},</p>
      <p>A marcação de <strong>${servico}</strong> em <strong>${dataHora}</strong> foi cancelada.</p>`,
  }),
  novaMensagem: (nomeDestinatario, nomeRemetente) => ({
    subject: 'Femme — Nova mensagem',
    html: `<p>Olá ${nomeDestinatario},</p>
      <p>Tens uma nova mensagem de <strong>${nomeRemetente}</strong>. Entra na plataforma para responder.</p>`,
  }),
  recuperarPassword: (nome, link) => ({
    subject: 'Femme — Recuperação de palavra-passe',
    html: `<p>Olá ${nome},</p>
      <p>Recebemos um pedido para redefinir a palavra-passe da tua conta Femme.</p>
      <p><a href="${link}" style="display:inline-block;padding:10px 20px;background:#d63384;color:#fff;
      border-radius:6px;text-decoration:none;">Redefinir palavra-passe</a></p>
      <p>Ou copia este link para o teu browser:<br>${link}</p>
      <p>Este link é válido durante 1 hora. Se não pediste esta recuperação, ignora este email —
      a tua palavra-passe mantém-se inalterada.</p>`,
  }),
};

module.exports = { enviarEmail, modelos };
