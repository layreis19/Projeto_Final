const pool = require('../db');

/**
 * Verificação "preguiçosa" (lazy check) do estado das marcações.
 *
 * Em vez de depender de um cron job ou de uma ação manual da profissional,
 * sempre que alguém consulta marcações (agenda da profissional, lista do
 * cliente, ou o próprio pedido de avaliação) corremos primeiro este UPDATE:
 * qualquer marcação que estava "confirmada" e cuja data/hora já passou
 * transita automaticamente para "concluida".
 *
 * Isto garante que o cliente consegue sempre avaliar um serviço que já
 * aconteceu, sem exigir que a profissional se lembre de marcar a marcação
 * como concluída manualmente.
 */
async function concluirMarcacoesPassadas() {
  await pool.query(
    "UPDATE marcacoes SET estado = 'concluida' WHERE estado = 'confirmada' AND data_hora < NOW()"
  );
}

module.exports = { concluirMarcacoesPassadas };
