const jwt = require('jsonwebtoken');

// Exige um token válido (qualquer tipo de utilizador) e anexa req.utilizador.
function autenticar(req, res, next) {
  const cabecalho = req.headers['authorization'] || '';
  const token = cabecalho.startsWith('Bearer ') ? cabecalho.slice(7) : null;
  if (!token) return res.status(401).json({ erro: 'Sessão não iniciada.' });

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.utilizador = payload; // { id, tipo }
    next();
  } catch (e) {
    return res.status(401).json({ erro: 'Sessão inválida ou expirada.' });
  }
}

// Exige um tipo específico de utilizador (cliente | profissional | admin).
function exigirTipo(tipo) {
  return (req, res, next) => {
    if (!req.utilizador || req.utilizador.tipo !== tipo) {
      return res.status(403).json({ erro: 'Acesso não autorizado.' });
    }
    next();
  };
}

module.exports = { autenticar, exigirTipo };
