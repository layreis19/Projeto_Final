require('dotenv').config();
require('express-async-errors'); // encaminha erros de handlers async para o middleware de erro
const express = require('express');
const cors = require('cors');
const path = require('path');
const swaggerUi = require('swagger-ui-express');

const swaggerSpec = require('./swagger');
const authRoutes = require('./routes/auth');
const publicoRoutes = require('./routes/publico');
const marcacoesRoutes = require('./routes/marcacoes');
const avaliacoesRoutes = require('./routes/avaliacoes');
const favoritosRoutes = require('./routes/favoritos');
const notificacoesRoutes = require('./routes/notificacoes');
const profissionalRoutes = require('./routes/profissional');
const disponibilidadeRoutes = require('./routes/disponibilidade');
const clienteRoutes = require('./routes/cliente');
const adminRoutes = require('./routes/admin');

const app = express();
app.use(cors());
app.use(express.json());

// Imagens de personalização da profissional (foto de perfil / banner) — pasta pública.
// Os documentos de aprovação NÃO são servidos aqui: ficam em uploads/documentos, privados.
app.use('/uploads', express.static(path.join(__dirname, 'uploads', 'imagens')));

// Documentação interativa da API — http://localhost:3000/api-docs
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.use('/api/auth', authRoutes);
app.use('/api', publicoRoutes); // /api/categorias, /api/profissionais, /api/servicos/:id
app.use('/api/marcacoes', marcacoesRoutes);
app.use('/api/avaliacoes', avaliacoesRoutes);
app.use('/api/favoritos', favoritosRoutes);
app.use('/api/notificacoes', notificacoesRoutes);
app.use('/api/profissional', profissionalRoutes);
app.use('/api/profissional', disponibilidadeRoutes);
app.use('/api/cliente', clienteRoutes);
app.use('/api/admin', adminRoutes);

// Tratamento de erros não capturados nas rotas.
// Erros do multer (tipo de ficheiro inválido, ficheiro grande demais) e outros erros
// de validação lançados como `new Error(...)` são devolvidos como 400 com a mensagem
// original; tudo o resto fica genérico (500) para não expor detalhes internos.
app.use((err, req, res, next) => {
  console.error(err);
  const erroDeValidacao = err.name === 'MulterError' || err.status === 400;
  res.status(erroDeValidacao ? 400 : 500).json({
    erro: erroDeValidacao ? err.message : 'Erro interno do servidor.',
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () =>
  console.log(`Femme API a correr em http://localhost:${PORT} (docs em /api-docs)`)
);

module.exports = app;
