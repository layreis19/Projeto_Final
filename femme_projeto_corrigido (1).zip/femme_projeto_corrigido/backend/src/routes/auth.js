const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const pool = require('../db');
const { enviarEmail, modelos } = require('../email');

const router = express.Router();

// Tempo de validade do link de recuperação de password.
const VALIDADE_RECUPERACAO_MINUTOS = 60;

function gerarTokenRecuperacao() {
  const token = crypto.randomBytes(32).toString('hex'); // vai por email, nunca guardado em claro na BD
  const hash = crypto.createHash('sha256').update(token).digest('hex');
  return { token, hash };
}

function gerarToken(utilizador) {
  return jwt.sign({ id: utilizador.id, tipo: utilizador.tipo }, process.env.JWT_SECRET, {
    expiresIn: '7d',
  });
}

function utilizadorPublico(row) {
  return { id: row.id, nome: row.nome, email: row.email, tipo: row.tipo };
}

/**
 * @openapi
 * /auth/registo:
 *   post:
 *     summary: Cria uma conta de cliente ou profissional
 *     tags: [Autenticação]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [nome, email, password, tipo]
 *             properties:
 *               nome: { type: string }
 *               email: { type: string }
 *               password: { type: string }
 *               tipo: { type: string, enum: [cliente, profissional] }
 *     responses:
 *       201: { description: Conta criada, devolve token + utilizador }
 *       400: { description: Dados em falta ou tipo inválido }
 *       409: { description: Já existe conta com este email }
 */
router.post('/registo', async (req, res) => {
  const { nome, email, password, tipo } = req.body;
  if (!nome || !email || !password || !tipo) {
    return res.status(400).json({ erro: 'Preenche todos os campos.' });
  }
  if (!['cliente', 'profissional'].includes(tipo)) {
    return res.status(400).json({ erro: 'Tipo de conta inválido.' });
  }

  const conn = await pool.getConnection();
  try {
    const [existentes] = await conn.query('SELECT id FROM utilizadores WHERE email = ?', [email]);
    if (existentes.length) {
      return res.status(409).json({ erro: 'Já existe uma conta com este email.' });
    }

    const hash = await bcrypt.hash(password, 10);
    await conn.beginTransaction();

    const [resultado] = await conn.query(
      'INSERT INTO utilizadores (nome, email, password_hash, tipo) VALUES (?, ?, ?, ?)',
      [nome, email, hash, tipo]
    );
    const utilizadorId = resultado.insertId;

    if (tipo === 'profissional') {
      await conn.query(
        'INSERT INTO profissionais (utilizador_id, nome_negocio, estado_aprovacao) VALUES (?, ?, ?)',
        [utilizadorId, nome, 'pendente']
      );
    }

    await conn.commit();

    const utilizador = { id: utilizadorId, nome, email, tipo };
    res.status(201).json({ token: gerarToken(utilizador), utilizador });
  } catch (e) {
    await conn.rollback();
    console.error(e);
    res.status(500).json({ erro: 'Não foi possível criar a conta.' });
  } finally {
    conn.release();
  }
});

/**
 * @openapi
 * /auth/login:
 *   post:
 *     summary: Inicia sessão e devolve um token JWT
 *     tags: [Autenticação]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [email, password]
 *             properties:
 *               email: { type: string }
 *               password: { type: string }
 *     responses:
 *       200: { description: Login efetuado, devolve token + utilizador }
 *       401: { description: Credenciais incorretas }
 *       403: { description: Conta desativada }
 */
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ erro: 'Preenche email e palavra-passe.' });

  try {
    const [rows] = await pool.query('SELECT * FROM utilizadores WHERE email = ?', [email]);
    const utilizador = rows[0];
    if (!utilizador || !(await bcrypt.compare(password, utilizador.password_hash || ''))) {
      return res.status(401).json({ erro: 'Email ou palavra-passe incorretos.' });
    }
    if (utilizador.estado === 'desativado') {
      return res.status(403).json({ erro: 'Esta conta está desativada.' });
    }
    res.json({ token: gerarToken(utilizador), utilizador: utilizadorPublico(utilizador) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: 'Erro ao iniciar sessão.' });
  }
});

/**
 * @openapi
 * /auth/recuperar-password:
 *   post:
 *     summary: Pede a recuperação da palavra-passe (envia um link por email)
 *     tags: [Autenticação]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [email]
 *             properties:
 *               email: { type: string }
 *     responses:
 *       200: { description: "Se existir conta com este email, foi enviado um link (resposta genérica, para não revelar quais emails têm conta)" }
 *       400: { description: Email em falta }
 */
router.post('/recuperar-password', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ erro: 'Indica o teu email.' });
  console.log(`Pedido de recuperação de password para ${email}`);

  const mensagem = { mensagem: 'Se existir uma conta com este email, vais receber um link de recuperação.' };

  try {
    const [rows] = await pool.query('SELECT * FROM utilizadores WHERE email = ?', [email]);
    const utilizador = rows[0];
      console.log(rows);


    // Resposta é sempre igual, exista ou não a conta, para não deixar descobrir
    // quais emails estão registados na plataforma.
    if (!utilizador) return res.json(mensagem);

    const { token, hash } = gerarTokenRecuperacao();
    const expiraEm = new Date(Date.now() + VALIDADE_RECUPERACAO_MINUTOS * 60 * 1000);

    await pool.query(
      'INSERT INTO recuperacao_password (utilizador_id, token_hash, expira_em) VALUES (?, ?, ?)',
      [utilizador.id, hash, expiraEm]
    );

    const baseFrontend = process.env.FRONTEND_URL || 'http://localhost:8080';
    const link = `${baseFrontend}/redefinir-password.html?token=${token}`;

    console.log(`Link de recuperação de password para ${utilizador.nome}: ${link}`);

    const { subject, html } = modelos.recuperarPassword(utilizador.nome, link);
    await enviarEmail({ to: utilizador.email, subject, html });

    res.json(mensagem);
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: 'Não foi possível processar o pedido de recuperação.' });
  }
});

/**
 * @openapi
 * /auth/redefinir-password:
 *   post:
 *     summary: Redefine a palavra-passe a partir do token recebido por email
 *     tags: [Autenticação]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [token, password]
 *             properties:
 *               token: { type: string }
 *               password: { type: string }
 *     responses:
 *       200: { description: Palavra-passe redefinida }
 *       400: { description: Link inválido, expirado ou já usado }
 */
router.post('/redefinir-password', async (req, res) => {
  const { token, password } = req.body;
  if (!token || !password) return res.status(400).json({ erro: 'Preenche o campo da nova palavra-passe.' });
  if (password.length < 6) return res.status(400).json({ erro: 'A palavra-passe deve ter no mínimo 6 caracteres.' });

  const hash = crypto.createHash('sha256').update(token).digest('hex');

  const conn = await pool.getConnection();
  try {
    const [rows] = await conn.query(
      `SELECT * FROM recuperacao_password
       WHERE token_hash = ? AND usado_em IS NULL AND expira_em > NOW()`,
      [hash]
    );
    const pedido = rows[0];
    if (!pedido) {
      return res.status(400).json({ erro: 'Este link é inválido ou já expirou. Pede uma nova recuperação.' });
    }

    const novoHash = await bcrypt.hash(password, 10);
    await conn.beginTransaction();
    await conn.query('UPDATE utilizadores SET password_hash = ? WHERE id = ?', [novoHash, pedido.utilizador_id]);
    await conn.query('UPDATE recuperacao_password SET usado_em = NOW() WHERE id = ?', [pedido.id]);
    await conn.commit();

    res.json({ mensagem: 'Palavra-passe redefinida com sucesso. Já podes iniciar sessão.' });
  } catch (e) {
    await conn.rollback();
    console.error(e);
    res.status(500).json({ erro: 'Não foi possível redefinir a palavra-passe.' });
  } finally {
    conn.release();
  }
});

module.exports = router;
