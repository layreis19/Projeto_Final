const express = require('express');
const bcrypt = require('bcrypt');
const pool = require('../db');
const { autenticar, exigirTipo } = require('../middleware/auth');

const router = express.Router();
router.use(autenticar, exigirTipo('cliente'));

/**
 * @openapi
 * /cliente/me:
 *   get:
 *     summary: Devolve os dados da conta do cliente autenticado
 *     tags: [Cliente]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Dados da conta }
 */
router.get('/me', async (req, res) => {
  const [rows] = await pool.query('SELECT id, nome, email, criado_em FROM utilizadores WHERE id = ?', [
    req.utilizador.id,
  ]);
  if (!rows.length) return res.status(404).json({ erro: 'Conta não encontrada.' });
  res.json(rows[0]);
});

/**
 * @openapi
 * /cliente/me:
 *   put:
 *     summary: Atualiza o nome e/ou email do cliente autenticado
 *     tags: [Cliente]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               nome: { type: string }
 *               email: { type: string }
 *     responses:
 *       200: { description: Dados atualizados }
 *       400: { description: Dados em falta }
 *       409: { description: Já existe outra conta com este email }
 */
router.put('/me', async (req, res) => {
  const { nome, email } = req.body;
  if (!nome || !email) return res.status(400).json({ erro: 'Preenche o nome e o email.' });

  const [existentes] = await pool.query('SELECT id FROM utilizadores WHERE email = ? AND id != ?', [
    email,
    req.utilizador.id,
  ]);
  if (existentes.length) return res.status(409).json({ erro: 'Já existe outra conta com este email.' });

  await pool.query('UPDATE utilizadores SET nome = ?, email = ? WHERE id = ?', [nome, email, req.utilizador.id]);
  res.json({ mensagem: 'Dados atualizados.' });
});

/**
 * @openapi
 * /cliente/password:
 *   put:
 *     summary: Muda a password do cliente autenticado
 *     tags: [Cliente]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [password_atual, password_nova]
 *             properties:
 *               password_atual: { type: string }
 *               password_nova: { type: string }
 *     responses:
 *       200: { description: Password atualizada }
 *       400: { description: Password nova demasiado curta }
 *       401: { description: Password atual incorreta }
 */
router.put('/password', async (req, res) => {
  const { password_atual, password_nova } = req.body;
  if (!password_atual || !password_nova) {
    return res.status(400).json({ erro: 'Preenche a password atual e a nova.' });
  }
  if (password_nova.length < 6) {
    return res.status(400).json({ erro: 'A nova password tem de ter pelo menos 6 caracteres.' });
  }

  const [rows] = await pool.query('SELECT password_hash FROM utilizadores WHERE id = ?', [req.utilizador.id]);
  const ok = rows.length && (await bcrypt.compare(password_atual, rows[0].password_hash || ''));
  if (!ok) return res.status(401).json({ erro: 'A password atual está incorreta.' });

  const hash = await bcrypt.hash(password_nova, 10);
  await pool.query('UPDATE utilizadores SET password_hash = ? WHERE id = ?', [hash, req.utilizador.id]);
  res.json({ mensagem: 'Password atualizada.' });
});

module.exports = router;
