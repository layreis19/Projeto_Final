const express = require('express');
const pool = require('../db');
const { autenticar } = require('../middleware/auth');

const router = express.Router();
router.use(autenticar);

/**
 * @openapi
 * /notificacoes:
 *   get:
 *     summary: Lista as notificações do utilizador autenticado (mais recentes primeiro)
 *     tags: [Notificações]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: apenas_nao_lidas
 *         schema: { type: boolean }
 *         description: Se "true", devolve só as notificações por ler
 *     responses:
 *       200: { description: Lista de notificações }
 */
router.get('/', async (req, res) => {
  const condicoes = ['utilizador_id = ?'];
  const params = [req.utilizador.id];
  if (req.query.apenas_nao_lidas === 'true') {
    condicoes.push('lida = FALSE');
  }
  const [rows] = await pool.query(
    `SELECT id, tipo, mensagem, lida, criado_em FROM notificacoes
     WHERE ${condicoes.join(' AND ')} ORDER BY criado_em DESC LIMIT 100`,
    params
  );
  res.json(rows);
});

/**
 * @openapi
 * /notificacoes/{id}/lida:
 *   put:
 *     summary: Marca uma notificação como lida
 *     tags: [Notificações]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Notificação marcada como lida }
 *       404: { description: Notificação não encontrada }
 */
router.put('/:id/lida', async (req, res) => {
  const [resultado] = await pool.query(
    'UPDATE notificacoes SET lida = TRUE WHERE id = ? AND utilizador_id = ?',
    [req.params.id, req.utilizador.id]
  );
  if (!resultado.affectedRows) return res.status(404).json({ erro: 'Notificação não encontrada.' });
  res.json({ mensagem: 'Notificação marcada como lida.' });
});

/**
 * @openapi
 * /notificacoes/lidas:
 *   put:
 *     summary: Marca todas as notificações do utilizador como lidas
 *     tags: [Notificações]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Todas as notificações marcadas como lidas }
 */
router.put('/lidas', async (req, res) => {
  await pool.query('UPDATE notificacoes SET lida = TRUE WHERE utilizador_id = ?', [req.utilizador.id]);
  res.json({ mensagem: 'Todas as notificações foram marcadas como lidas.' });
});

module.exports = router;
