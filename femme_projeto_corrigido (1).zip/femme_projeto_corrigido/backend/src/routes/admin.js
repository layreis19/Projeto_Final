const express = require('express');
const pool = require('../db');
const { autenticar, exigirTipo } = require('../middleware/auth');

const router = express.Router();
router.use(autenticar, exigirTipo('admin'));

/**
 * @openapi
 * /admin/aprovacoes:
 *   get:
 *     summary: Lista profissionais pendentes de aprovação
 *     tags: [Admin]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Lista de profissionais pendentes }
 */
router.get('/aprovacoes', async (req, res) => {
  const [rows] = await pool.query(
    `SELECT p.id, p.nome_negocio, p.criado_em, u.nome, u.email,
            (SELECT COUNT(*) FROM profissional_documentos d WHERE d.profissional_id = p.id) AS documentos_enviados
     FROM profissionais p JOIN utilizadores u ON u.id = p.utilizador_id
     WHERE p.estado_aprovacao = 'pendente'
     ORDER BY p.criado_em ASC`
  );
  res.json(rows);
});

/**
 * @openapi
 * /admin/profissionais/{id}/aprovar:
 *   put:
 *     summary: Aprova uma profissional pendente
 *     tags: [Admin]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Profissional aprovada }
 *       404: { description: Profissional não encontrada }
 */
router.put('/profissionais/:id/aprovar', async (req, res) => {
  const [resultado] = await pool.query("UPDATE profissionais SET estado_aprovacao = 'aprovado' WHERE id = ?", [
    req.params.id,
  ]);
  if (!resultado.affectedRows) return res.status(404).json({ erro: 'Profissional não encontrada.' });
  res.json({ mensagem: 'Profissional aprovada.' });
});

/**
 * @openapi
 * /admin/profissionais/{id}/rejeitar:
 *   put:
 *     summary: Rejeita uma profissional pendente
 *     tags: [Admin]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Profissional rejeitada }
 *       404: { description: Profissional não encontrada }
 */
router.put('/profissionais/:id/rejeitar', async (req, res) => {
  const [resultado] = await pool.query("UPDATE profissionais SET estado_aprovacao = 'rejeitado' WHERE id = ?", [
    req.params.id,
  ]);
  if (!resultado.affectedRows) return res.status(404).json({ erro: 'Profissional não encontrada.' });
  res.json({ mensagem: 'Profissional rejeitada.' });
});

/**
 * @openapi
 * /admin/utilizadores:
 *   get:
 *     summary: Lista todos os utilizadores
 *     tags: [Admin]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Lista de utilizadores }
 */
router.get('/utilizadores', async (req, res) => {
  const [rows] = await pool.query('SELECT id, nome, email, tipo, estado FROM utilizadores ORDER BY nome');
  res.json(rows);
});

/**
 * @openapi
 * /admin/utilizadores/{id}/estado:
 *   put:
 *     summary: Ativa ou desativa um utilizador
 *     tags: [Admin]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [estado]
 *             properties:
 *               estado: { type: string, enum: [ativo, desativado] }
 *     responses:
 *       200: { description: Estado atualizado }
 *       400: { description: Estado inválido }
 *       404: { description: Utilizador não encontrado }
 */
router.put('/utilizadores/:id/estado', async (req, res) => {
  const { estado } = req.body;
  if (!['ativo', 'desativado'].includes(estado)) return res.status(400).json({ erro: 'Estado inválido.' });

  if (Number(req.params.id) === req.utilizador.id) {
    return res.status(400).json({ erro: 'Não podes ativar/desativar a tua própria conta.' });
  }
  const [[alvo]] = await pool.query('SELECT tipo FROM utilizadores WHERE id = ?', [req.params.id]);
  if (!alvo) return res.status(404).json({ erro: 'Utilizador não encontrado.' });
  if (alvo.tipo === 'admin') return res.status(400).json({ erro: 'Não é possível desativar outra conta de administrador.' });

  const [resultado] = await pool.query('UPDATE utilizadores SET estado = ? WHERE id = ?', [estado, req.params.id]);
  if (!resultado.affectedRows) return res.status(404).json({ erro: 'Utilizador não encontrado.' });
  res.json({ mensagem: 'Estado do utilizador atualizado.' });
});

/**
 * @openapi
 * /admin/avaliacoes:
 *   get:
 *     summary: Lista avaliações pendentes de moderação
 *     tags: [Admin]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Lista de avaliações pendentes }
 */
router.get('/avaliacoes', async (req, res) => {
  const [rows] = await pool.query(
    `SELECT a.id, a.nota AS classificacao, a.comentario, a.criado_em,
            cli.nome AS cliente_nome, p.nome_negocio AS profissional_nome
     FROM avaliacoes a
     JOIN marcacoes m ON m.id = a.marcacao_id
     JOIN utilizadores cli ON cli.id = m.cliente_id
     JOIN profissionais p ON p.id = m.profissional_id
     WHERE a.estado = 'pendente'
     ORDER BY a.criado_em ASC`
  );
  res.json(rows);
});

/**
 * @openapi
 * /admin/avaliacoes/{id}/publicar:
 *   put:
 *     summary: Publica uma avaliação pendente
 *     tags: [Admin]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Avaliação publicada }
 *       404: { description: Avaliação não encontrada }
 */
router.put('/avaliacoes/:id/publicar', async (req, res) => {
  const [resultado] = await pool.query("UPDATE avaliacoes SET estado = 'publicada' WHERE id = ?", [req.params.id]);
  if (!resultado.affectedRows) return res.status(404).json({ erro: 'Avaliação não encontrada.' });
  res.json({ mensagem: 'Avaliação publicada.' });
});

/**
 * @openapi
 * /admin/avaliacoes/{id}/rejeitar:
 *   put:
 *     summary: Rejeita uma avaliação pendente
 *     tags: [Admin]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Avaliação rejeitada }
 *       404: { description: Avaliação não encontrada }
 */
router.put('/avaliacoes/:id/rejeitar', async (req, res) => {
  const [resultado] = await pool.query("UPDATE avaliacoes SET estado = 'rejeitado' WHERE id = ?", [req.params.id]);
  if (!resultado.affectedRows) return res.status(404).json({ erro: 'Avaliação não encontrada.' });
  res.json({ mensagem: 'Avaliação rejeitada.' });
});

module.exports = router;
