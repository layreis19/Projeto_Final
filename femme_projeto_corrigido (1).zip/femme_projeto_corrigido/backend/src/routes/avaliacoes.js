const express = require('express');
const pool = require('../db');
const { autenticar, exigirTipo } = require('../middleware/auth');
const { concluirMarcacoesPassadas } = require('../utils/concluirMarcacoes');

const router = express.Router();

/**
 * @openapi
 * /avaliacoes:
 *   post:
 *     summary: Cliente avalia uma marcação concluída
 *     tags: [Avaliações]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [id_marcacao, classificacao]
 *             properties:
 *               id_marcacao: { type: integer }
 *               classificacao: { type: integer, minimum: 1, maximum: 5 }
 *               comentario: { type: string }
 *     responses:
 *       201: { description: Avaliação enviada para moderação }
 *       404: { description: Marcação não encontrada ou ainda não concluída }
 *       409: { description: Marcação já avaliada }
 */
router.post('/', autenticar, exigirTipo('cliente'), async (req, res) => {
  const { id_marcacao, classificacao, comentario } = req.body;
  if (!id_marcacao || !classificacao) {
    return res.status(400).json({ erro: 'Escolhe uma classificação para a marcação.' });
  }
  if (classificacao < 1 || classificacao > 5) {
    return res.status(400).json({ erro: 'A classificação tem de estar entre 1 e 5.' });
  }

  // Garante que uma marcação "confirmada" cuja hora já passou é atualizada
  // para "concluida" antes de verificarmos se pode ser avaliada.
  await concluirMarcacoesPassadas();

  const [rows] = await pool.query(
    "SELECT id FROM marcacoes WHERE id = ? AND cliente_id = ? AND estado = 'concluida'",
    [id_marcacao, req.utilizador.id]
  );
  if (!rows.length) return res.status(404).json({ erro: 'Marcação não encontrada ou ainda não concluída.' });

  try {
    const [resultado] = await pool.query(
      "INSERT INTO avaliacoes (marcacao_id, nota, comentario, estado) VALUES (?, ?, ?, 'pendente')",
      [id_marcacao, classificacao, comentario || null]
    );
    res.status(201).json({ id: resultado.insertId, mensagem: 'Avaliação enviada para moderação.' });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ erro: 'Já avaliaste esta marcação.' });
    throw e;
  }
});

module.exports = router;
