const express = require('express');
const pool = require('../db');
const { autenticar, exigirTipo } = require('../middleware/auth');

const router = express.Router();
router.use(autenticar, exigirTipo('cliente'));

/**
 * @openapi
 * /favoritos:
 *   get:
 *     summary: Lista as profissionais guardadas como favoritas pelo cliente autenticado
 *     tags: [Favoritos]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200:
 *         description: Lista de profissionais favoritas
 */
router.get('/', async (req, res) => {
  const [rows] = await pool.query(
    `SELECT p.id, p.nome_negocio, p.localizacao, p.foto_perfil, c.nome AS categoria,
            (SELECT ROUND(AVG(a.nota), 1) FROM avaliacoes a
               JOIN marcacoes m ON m.id = a.marcacao_id
               WHERE m.profissional_id = p.id AND a.estado = 'publicada') AS classificacao_media,
            f.criado_em AS guardado_em
     FROM favoritos f
     JOIN profissionais p ON p.id = f.profissional_id
     LEFT JOIN categorias c ON c.id = p.categoria_id
     WHERE f.utilizador_id = ?
     ORDER BY f.criado_em DESC`,
    [req.utilizador.id]
  );
  res.json(rows);
});

/**
 * @openapi
 * /favoritos/{profissionalId}:
 *   post:
 *     summary: Adiciona uma profissional aos favoritos
 *     tags: [Favoritos]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: profissionalId
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       201: { description: Adicionada aos favoritos }
 *       404: { description: Profissional não encontrada }
 *       409: { description: Já está nos favoritos }
 */
router.post('/:profissionalId', async (req, res) => {
  const [existe] = await pool.query(
    "SELECT id FROM profissionais WHERE id = ? AND estado_aprovacao = 'aprovado'",
    [req.params.profissionalId]
  );
  if (!existe.length) return res.status(404).json({ erro: 'Profissional não encontrada.' });

  try {
    await pool.query('INSERT INTO favoritos (utilizador_id, profissional_id) VALUES (?, ?)', [
      req.utilizador.id,
      req.params.profissionalId,
    ]);
    res.status(201).json({ mensagem: 'Adicionada aos favoritos.' });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ erro: 'Já está nos teus favoritos.' });
    throw e;
  }
});

/**
 * @openapi
 * /favoritos/{profissionalId}:
 *   delete:
 *     summary: Remove uma profissional dos favoritos
 *     tags: [Favoritos]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: profissionalId
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Removida dos favoritos }
 *       404: { description: Não estava nos favoritos }
 */
router.delete('/:profissionalId', async (req, res) => {
  const [resultado] = await pool.query(
    'DELETE FROM favoritos WHERE utilizador_id = ? AND profissional_id = ?',
    [req.utilizador.id, req.params.profissionalId]
  );
  if (!resultado.affectedRows) return res.status(404).json({ erro: 'Não estava nos favoritos.' });
  res.json({ mensagem: 'Removida dos favoritos.' });
});

module.exports = router;
