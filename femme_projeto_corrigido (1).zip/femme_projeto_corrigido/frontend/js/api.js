// Camada de acesso à API Femme.
// O backend passa a ser Node.js/Express, com a ligação à base de dados MySQL
// feita em JavaScript (ex.: driver mysql2) — o contrato da API mantém-se igual.
const API_BASE = "http://localhost:3000/api";
// Base para imagens públicas (foto de perfil/banner) guardadas pelo backend em /uploads.
// Derivada de API_BASE para só existir um sítio a mudar se a API mudar de endereço.
const UPLOADS_BASE = API_BASE.replace(/\/api\/?$/, "");

async function apiFetch(path, { method = "GET", body, auth = true } = {}) {
  const headers = { "Content-Type": "application/json" };
  const token = localStorage.getItem("femme_token");
  if (auth && token) headers["Authorization"] = `Bearer ${token}`;

  const resp = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  let data = null;
  try { data = await resp.json(); } catch (e) { /* resposta sem corpo */ }

  if (!resp.ok) {
    throw new Error((data && data.erro) || `Erro ${resp.status}`);
  }
  return data;
}

const Sessao = {
  guardar(token, utilizador) {
    localStorage.setItem("femme_token", token);
    localStorage.setItem("femme_user", JSON.stringify(utilizador));
  },
  utilizador() {
    const raw = localStorage.getItem("femme_user");
    return raw ? JSON.parse(raw) : null;
  },
  token() { return localStorage.getItem("femme_token"); },
  terminar() {
    localStorage.removeItem("femme_token");
    localStorage.removeItem("femme_user");
  },
  exigirTipo(tipo, paginaLogin) {
    const user = Sessao.utilizador();
    if (!user || !Sessao.token() || user.tipo !== tipo) {
      window.location.href = paginaLogin;
    }
    return user;
  },
  // Exige apenas que exista sessão iniciada (qualquer tipo de utilizador).
  // Usado em páginas públicas que passam a só ficar visíveis depois de login (ex.: Descobrir).
  exigirLogin(paginaLogin) {
    const user = Sessao.utilizador();
    if (!user || !Sessao.token()) {
      const destino = encodeURIComponent(window.location.pathname + window.location.search);
      window.location.href = `${paginaLogin}?next=${destino}`;
      return null;
    }
    return user;
  },
};

// Envio de ficheiros (multipart/form-data) — usado, por exemplo, no upload dos
// documentos do profissional para aprovação do administrador.
async function apiUpload(path, formData) {
  const headers = {};
  const token = localStorage.getItem("femme_token");
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const resp = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers, // sem Content-Type: o browser define o boundary do multipart automaticamente
    body: formData,
  });

  let data = null;
  try { data = await resp.json(); } catch (e) { /* resposta sem corpo */ }

  if (!resp.ok) {
    throw new Error((data && data.erro) || `Erro ${resp.status}`);
  }
  return data;
}

function alertaErro(container, mensagem) {
  container.innerHTML = `<div class="alert alert-danger py-2">${mensagem}</div>`;
}
function alertaSucesso(container, mensagem) {
  container.innerHTML = `<div class="alert alert-success py-2">${mensagem}</div>`;
}
function formatarData(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString("pt-PT", { weekday: "short", day: "2-digit", month: "short" }) +
    " · " + d.toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" });
}
const ROTULOS_ESTADO = {
  pendente: "Pendente", confirmada: "Confirmada", recusada: "Recusada",
  cancelada: "Cancelada", concluida: "Concluída", aprovado: "Aprovado",
  rejeitado: "Rejeitado", publicada: "Publicada", ativo: "Ativa", desativado: "Desativada",
};
const CORES_BADGE = {
  pendente: "warning", confirmada: "success", recusada: "secondary",
  cancelada: "secondary", concluida: "primary", aprovado: "success",
  rejeitado: "secondary", publicada: "success", ativo: "success", desativado: "secondary",
};
function badgeEstado(estado) {
  return `<span class="badge text-bg-${CORES_BADGE[estado] || "secondary"}">${ROTULOS_ESTADO[estado] || estado}</span>`;
}

// Atualiza o contador de notificações não lidas no sino da navegação.
// Chamar em qualquer página autenticada que tenha um elemento com este id no HTML:
//   <a class="nav-link notif-bell" href="notificacoes.html">🔔<span id="notifBadge" class="badge rounded-pill bg-danger notif-badge d-none">0</span></a>
async function atualizarBadgeNotificacoes(idElemento = "notifBadge") {
  const badge = document.getElementById(idElemento);
  if (!badge) return;
  try {
    const naoLidas = await apiFetch("/notificacoes?apenas_nao_lidas=true");
    if (naoLidas.length) {
      badge.textContent = naoLidas.length > 9 ? "9+" : naoLidas.length;
      badge.classList.remove("d-none");
    } else {
      badge.classList.add("d-none");
    }
  } catch (e) {
    // Falha silenciosa: o sino não deve bloquear a página por causa disto.
  }
}

// Ícones simples por tipo de notificação, usados em notificacoes.html.
const ICONES_NOTIFICACAO = { marcacao: "📅", mensagem: "💬", avaliacao: "⭐", sistema: "🔔" };

// Atualiza o contador de pedidos de marcação pendentes no menu da profissional.
// Chamar em qualquer página da área da profissional que tenha:
//   <a class="nav-link" href="pedidos.html">Pedidos<span id="pendBadge" class="badge rounded-pill bg-danger ms-1 d-none">0</span></a>
async function atualizarBadgePendentes(idElemento = "pendBadge") {
  const badge = document.getElementById(idElemento);
  if (!badge) return;
  try {
    const pendentes = await apiFetch("/profissional/marcacoes?estado=pendente");
    if (pendentes.length) {
      badge.textContent = pendentes.length > 9 ? "9+" : pendentes.length;
      badge.classList.remove("d-none");
    } else {
      badge.classList.add("d-none");
    }
  } catch (e) {
    // Falha silenciosa: o badge não deve bloquear a página por causa disto.
  }
}
