const express = require('express');
const pool = require('../db');
const { autenticar } = require('../middleware/auth');
const { enviarEmail, modelos } = require('../email');

const router = express.Router();
router.use(autenticar);

// Confirma que o utilizador autenticado é cliente ou profissional desta marcação.
async function carregarMarcacaoDoUtilizador(conn, marcacaoId, utilizador) {
  const [rows] = await conn.query(
    `SELECT m.*, p.utilizador_id AS profissional_utilizador_id
     FROM marcacoes m JOIN profissionais p ON p.id = m.profissional_id
     WHERE m.id = ?`,
    [marcacaoId]
  );
  const marcacao = rows[0];
  if (!marcacao) return null;
  const ehCliente = utilizador.tipo === 'cliente' && marcacao.cliente_id === utilizador.id;
  const ehProfissional = utilizador.tipo === 'profissional' && marcacao.profissional_utilizador_id === utilizador.id;
  return ehCliente || ehProfissional ? marcacao : null;
}

function formatarDataPt(dataHora) {
  const d = new Date(dataHora);
  return d.toLocaleString('pt-PT', { dateStyle: 'medium', timeStyle: 'short' });
}

// Devolve "HH:MM" a partir de um Date, para comparar com as colunas TIME de disponibilidades.
function horaMinuto(date) {
  return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}:00`;
}

/**
 * Valida se um pedido de marcação [inicio, fim) é permitido para a profissional:
 *  1. não pode ser no passado;
 *  2. tem de cair dentro de um horário de atendimento definido (disponibilidades);
 *  3. não pode sobrepor-se a um bloqueio de agenda (férias, folgas, etc.);
 *  4. não pode sobrepor-se a outra marcação já pendente/confirmada da mesma profissional.
 * Devolve `null` se estiver tudo bem, ou uma string com o motivo da rejeição.
 */
async function validarHorario(conn, profissionalId, inicio, duracaoMinutos, ignorarMarcacaoId = null) {
  if (Number.isNaN(inicio.getTime())) return 'Data e hora inválidas.';

  const agora = new Date();
  if (inicio <= agora) return 'Não é possível marcar num horário que já passou.';

  const fim = new Date(inicio.getTime() + duracaoMinutos * 60000);
  const diaSemana = inicio.getDay(); // 0=domingo ... 6=sábado, igual à coluna disponibilidades.dia_semana

  const [disponibilidades] = await conn.query(
    `SELECT 1 FROM disponibilidades
     WHERE profissional_id = ? AND dia_semana = ? AND hora_inicio <= ? AND hora_fim >= ?
     LIMIT 1`,
    [profissionalId, diaSemana, horaMinuto(inicio), horaMinuto(fim)]
  );
  if (!disponibilidades.length) return 'Esse horário está fora do horário de atendimento da profissional.';

  const [bloqueios] = await conn.query(
    `SELECT 1 FROM bloqueios_agenda
     WHERE profissional_id = ? AND data_inicio < ? AND data_fim > ?
     LIMIT 1`,
    [profissionalId, fim, inicio]
  );
  if (bloqueios.length) return 'Esse horário está bloqueado pela profissional (ex.: férias ou folga).';

  const params = [profissionalId, fim, inicio];
  let sqlIgnorar = '';
  if (ignorarMarcacaoId) {
    sqlIgnorar = ' AND m.id != ?';
    params.push(ignorarMarcacaoId);
  }
  const [conflitos] = await conn.query(
    `SELECT 1 FROM marcacoes m
     WHERE m.profissional_id = ? AND m.estado IN ('pendente','confirmada')
       AND m.data_hora < ? AND DATE_ADD(m.data_hora, INTERVAL m.duracao_no_momento MINUTE) > ?
       ${sqlIgnorar}
     LIMIT 1`,
    params
  );
  if (conflitos.length) return 'Já existe outra marcação nesse horário.';

  return null;
}

/**
 * @openapi
 * /marcacoes:
 *   post:
 *     summary: Cliente pede uma marcação de um serviço
 *     tags: [Marcações]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [id_servico, data_hora]
 *             properties:
 *               id_servico: { type: integer }
 *               data_hora: { type: string, format: date-time }
 *               notas: { type: string }
 *     responses:
 *       201: { description: Pedido de marcação enviado }
 *       400: { description: Horário inválido, indisponível ou já ocupado }
 */
router.post('/', async (req, res) => {
  if (req.utilizador.tipo !== 'cliente') return res.status(403).json({ erro: 'Só clientes podem marcar serviços.' });

  const { id_servico, data_hora, notas } = req.body;
  if (!id_servico || !data_hora) return res.status(400).json({ erro: 'Escolhe o serviço e a data/hora.' });

  const [servicoRows] = await pool.query(
    `SELECT s.id, s.profissional_id, s.nome, s.preco, s.duracao_minutos,
            p.nome_negocio, u.id AS utilizador_id, u.nome AS profissional_nome, u.email AS profissional_email
     FROM servicos s
     JOIN profissionais p ON p.id = s.profissional_id
     JOIN utilizadores u ON u.id = p.utilizador_id
     WHERE s.id = ? AND s.ativo = TRUE`,
    [id_servico]
  );
  const servico = servicoRows[0];
  if (!servico) return res.status(404).json({ erro: 'Serviço não encontrado.' });

  const [[cliente]] = await pool.query('SELECT nome FROM utilizadores WHERE id = ?', [req.utilizador.id]);

  const conn = await pool.getConnection();
  try {
    const inicio = new Date(data_hora);
    const erroHorario = await validarHorario(conn, servico.profissional_id, inicio, servico.duracao_minutos);
    if (erroHorario) return res.status(400).json({ erro: erroHorario });

    const [resultado] = await conn.query(
      `INSERT INTO marcacoes (cliente_id, profissional_id, servico_id, data_hora, preco_no_momento, duracao_no_momento, estado)
       VALUES (?, ?, ?, ?, ?, ?, 'pendente')`,
      [req.utilizador.id, servico.profissional_id, servico.id, data_hora, servico.preco, servico.duracao_minutos]
    );

    await conn.query(
      "INSERT INTO notificacoes (utilizador_id, tipo, mensagem) VALUES (?, 'marcacao', 'Novo pedido de marcação.')",
      [servico.utilizador_id]
    );

    enviarEmail({
      to: servico.profissional_email,
      ...modelos.novaMarcacaoParaProfissional(servico.profissional_nome, cliente.nome, servico.nome, formatarDataPt(data_hora)),
    });

    res.status(201).json({ id: resultado.insertId, mensagem: 'Pedido de marcação enviado.' });
  } finally {
    conn.release();
  }
});

/**
 * @openapi
 * /marcacoes/minhas:
 *   get:
 *     summary: Lista as marcações do cliente autenticado
 *     tags: [Marcações]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Lista de marcações }
 */
router.get('/minhas', async (req, res) => {
  if (req.utilizador.tipo !== 'cliente') return res.status(403).json({ erro: 'Acesso não autorizado.' });

  const [rows] = await pool.query(
    `SELECT m.id, m.data_hora, m.preco_no_momento, m.duracao_no_momento, m.estado,
            s.nome AS servico_nome, p.nome_negocio AS profissional_nome, p.id AS profissional_id,
            (SELECT COUNT(*) FROM avaliacoes a WHERE a.marcacao_id = m.id) > 0 AS tem_avaliacao
     FROM marcacoes m
     JOIN servicos s ON s.id = m.servico_id
     JOIN profissionais p ON p.id = m.profissional_id
     WHERE m.cliente_id = ?
     ORDER BY m.data_hora DESC`,
    [req.utilizador.id]
  );
  res.json(rows);
});

/**
 * @openapi
 * /marcacoes/{id}/cancelar:
 *   put:
 *     summary: Cancela uma marcação (cliente ou profissional envolvidos)
 *     tags: [Marcações]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Marcação cancelada }
 *       404: { description: Marcação não encontrada }
 */
router.put('/:id/cancelar', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    const marcacao = await carregarMarcacaoDoUtilizador(conn, req.params.id, req.utilizador);
    if (!marcacao) return res.status(404).json({ erro: 'Marcação não encontrada.' });
    if (['cancelada', 'concluida'].includes(marcacao.estado)) {
      return res.status(400).json({ erro: 'Esta marcação já não pode ser cancelada.' });
    }
    await conn.query("UPDATE marcacoes SET estado = 'cancelada' WHERE id = ?", [req.params.id]);

    const [[detalhe]] = await conn.query(
      `SELECT s.nome AS servico_nome, m.data_hora,
              cli.nome AS cliente_nome, cli.email AS cliente_email,
              prof.nome AS profissional_nome, prof.email AS profissional_email
       FROM marcacoes m
       JOIN servicos s ON s.id = m.servico_id
       JOIN utilizadores cli ON cli.id = m.cliente_id
       JOIN profissionais p ON p.id = m.profissional_id
       JOIN utilizadores prof ON prof.id = p.utilizador_id
       WHERE m.id = ?`,
      [req.params.id]
    );
    const dataFormatada = formatarDataPt(detalhe.data_hora);
    // Avisa sempre a outra parte (quem não cancelou não deu o pedido de cancelamento).
    const outraParte =
      req.utilizador.id === marcacao.cliente_id
        ? { nome: detalhe.profissional_nome, email: detalhe.profissional_email }
        : { nome: detalhe.cliente_nome, email: detalhe.cliente_email };
    enviarEmail({ to: outraParte.email, ...modelos.cancelamento(outraParte.nome, detalhe.servico_nome, dataFormatada) });

    res.json({ mensagem: 'Marcação cancelada.' });
  } finally {
    conn.release();
  }
});

/**
 * @openapi
 * /marcacoes/conversas:
 *   get:
 *     summary: Lista as conversas do utilizador autenticado (uma por marcação), com a última mensagem
 *     tags: [Marcações]
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Lista de conversas }
 */
router.get('/conversas', async (req, res) => {
  const ehCliente = req.utilizador.tipo === 'cliente';
  const ehProfissional = req.utilizador.tipo === 'profissional';
  if (!ehCliente && !ehProfissional) return res.status(403).json({ erro: 'Acesso não autorizado.' });

  const condicaoUtilizador = ehCliente ? 'm.cliente_id = ?' : 'p.utilizador_id = ?';

  const [rows] = await pool.query(
    `SELECT m.id AS marcacao_id, m.data_hora, m.estado, s.nome AS servico_nome,
            ${ehCliente ? 'p.nome_negocio' : 'cli.nome'} AS outra_parte_nome,
            (SELECT texto FROM mensagens WHERE marcacao_id = m.id ORDER BY enviado_em DESC LIMIT 1) AS ultima_mensagem,
            (SELECT enviado_em FROM mensagens WHERE marcacao_id = m.id ORDER BY enviado_em DESC LIMIT 1) AS ultima_mensagem_em,
            (SELECT COUNT(*) FROM mensagens msg WHERE msg.marcacao_id = m.id AND msg.destinatario_id = ? AND msg.lida = FALSE) AS nao_lidas
     FROM marcacoes m
     JOIN servicos s ON s.id = m.servico_id
     JOIN profissionais p ON p.id = m.profissional_id
     JOIN utilizadores cli ON cli.id = m.cliente_id
     WHERE ${condicaoUtilizador} AND EXISTS (SELECT 1 FROM mensagens WHERE marcacao_id = m.id)
     ORDER BY ultima_mensagem_em DESC`,
    [req.utilizador.id, req.utilizador.id]
  );
  res.json(rows);
});

/**
 * @openapi
 * /marcacoes/{id}/mensagens:
 *   get:
 *     summary: Lista as mensagens trocadas numa marcação (marca-as como lidas para quem consulta)
 *     tags: [Marcações]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Lista de mensagens }
 */
router.get('/:id/mensagens', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    const marcacao = await carregarMarcacaoDoUtilizador(conn, req.params.id, req.utilizador);
    if (!marcacao) return res.status(404).json({ erro: 'Marcação não encontrada.' });

    const [mensagens] = await conn.query(
      `SELECT id, remetente_id AS id_remetente, destinatario_id AS id_destinatario, texto AS conteudo, enviado_em
       FROM mensagens WHERE marcacao_id = ? ORDER BY enviado_em ASC`,
      [req.params.id]
    );
    // Marca como lidas as mensagens que chegaram para o utilizador que está a consultar agora.
    await conn.query('UPDATE mensagens SET lida = TRUE WHERE marcacao_id = ? AND destinatario_id = ?', [
      req.params.id,
      req.utilizador.id,
    ]);
    res.json(mensagens);
  } finally {
    conn.release();
  }
});

/**
 * @openapi
 * /marcacoes/{id}/mensagens:
 *   post:
 *     summary: Envia uma mensagem no contexto de uma marcação
 *     tags: [Marcações]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [conteudo]
 *             properties:
 *               conteudo: { type: string }
 *     responses:
 *       201: { description: Mensagem enviada }
 */
router.post('/:id/mensagens', async (req, res) => {
  const { conteudo } = req.body;
  if (!conteudo || !conteudo.trim()) return res.status(400).json({ erro: 'Escreve uma mensagem.' });

  const conn = await pool.getConnection();
  try {
    const marcacao = await carregarMarcacaoDoUtilizador(conn, req.params.id, req.utilizador);
    if (!marcacao) return res.status(404).json({ erro: 'Marcação não encontrada.' });

    const destinatarioId =
      req.utilizador.id === marcacao.cliente_id ? marcacao.profissional_utilizador_id : marcacao.cliente_id;

    const [resultado] = await conn.query(
      'INSERT INTO mensagens (marcacao_id, remetente_id, destinatario_id, texto) VALUES (?, ?, ?, ?)',
      [req.params.id, req.utilizador.id, destinatarioId, conteudo.trim()]
    );
    await conn.query(
      "INSERT INTO notificacoes (utilizador_id, tipo, mensagem) VALUES (?, 'mensagem', 'Nova mensagem recebida.')",
      [destinatarioId]
    );

    const [[destinatario]] = await conn.query('SELECT nome, email FROM utilizadores WHERE id = ?', [destinatarioId]);
    const [[remetente]] = await conn.query('SELECT nome FROM utilizadores WHERE id = ?', [req.utilizador.id]);
    if (destinatario) {
      enviarEmail({ to: destinatario.email, ...modelos.novaMensagem(destinatario.nome, remetente.nome) });
    }

    res.status(201).json({ id: resultado.insertId });
  } finally {
    conn.release();
  }
});

module.exports = router;
