const express = require('express');
const pool = require('../db');

const router = express.Router();

// Normaliza os campos DECIMAL do mysql2 (vêm como string) para Number.
function paraNumero(servico) {
  return { ...servico, preco: servico.preco != null ? Number(servico.preco) : servico.preco };
}

/**
 * @openapi
 * /categorias:
 *   get:
 *     summary: Lista todas as categorias de serviços
 *     tags: [Público]
 *     responses:
 *       200: { description: Lista de categorias }
 */
router.get('/categorias', async (req, res) => {
  const [rows] = await pool.query('SELECT id, nome FROM categorias ORDER BY nome');
  res.json(rows);
});

/**
 * @openapi
 * /profissionais:
 *   get:
 *     summary: Pesquisa profissionais aprovadas (por nome/categoria/localização)
 *     tags: [Público]
 *     parameters:
 *       - in: query
 *         name: q
 *         schema: { type: string }
 *       - in: query
 *         name: categoria
 *         schema: { type: integer }
 *       - in: query
 *         name: localizacao
 *         schema: { type: string }
 *         description: Filtra por zona/cidade (pesquisa parcial, sem distinguir maiúsculas)
 *     responses:
 *       200: { description: Lista de profissionais }
 */
router.get('/profissionais', async (req, res) => {
  const { q, categoria, localizacao } = req.query;
  const condicoes = ["p.estado_aprovacao = 'aprovado'", "u.estado = 'ativo'"];
  const params = [];

  if (q) {
    condicoes.push('(p.nome_negocio LIKE ? OR c.nome LIKE ?)');
    params.push(`%${q}%`, `%${q}%`);
  }
  if (categoria) {
    condicoes.push('p.categoria_id = ?');
    params.push(categoria);
  }
  if (localizacao) {
    condicoes.push('p.localizacao LIKE ?');
    params.push(`%${localizacao}%`);
  }

  const [rows] = await pool.query(
    `SELECT p.id, p.nome_negocio, p.localizacao, p.foto_perfil, c.nome AS categoria,
            (SELECT ROUND(AVG(a.nota), 1) FROM avaliacoes a
               JOIN marcacoes m ON m.id = a.marcacao_id
               WHERE m.profissional_id = p.id AND a.estado = 'publicada') AS classificacao_media,
            (SELECT COUNT(*) FROM avaliacoes a
               JOIN marcacoes m ON m.id = a.marcacao_id
               WHERE m.profissional_id = p.id AND a.estado = 'publicada') AS total_avaliacoes
     FROM profissionais p
     JOIN utilizadores u ON u.id = p.utilizador_id
     LEFT JOIN categorias c ON c.id = p.categoria_id
     WHERE ${condicoes.join(' AND ')}
     ORDER BY p.nome_negocio`,
    params
  );
  res.json(rows);
});

/**
 * @openapi
 * /profissionais/{id}:
 *   get:
 *     summary: Página pública de uma profissional (perfil, serviços, fotos)
 *     tags: [Público]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Perfil da profissional }
 *       404: { description: Profissional não encontrada }
 */
router.get('/profissionais/:id', async (req, res) => {
  const [rows] = await pool.query(
    `SELECT p.id, p.nome_negocio, p.descricao AS bio, p.instagram, p.localizacao,
            p.foto_perfil, p.foto_banner, c.nome AS categoria,
            (SELECT ROUND(AVG(a.nota), 1) FROM avaliacoes a
               JOIN marcacoes m ON m.id = a.marcacao_id
               WHERE m.profissional_id = p.id AND a.estado = 'publicada') AS classificacao_media,
            (SELECT COUNT(*) FROM avaliacoes a
               JOIN marcacoes m ON m.id = a.marcacao_id
               WHERE m.profissional_id = p.id AND a.estado = 'publicada') AS total_avaliacoes
     FROM profissionais p
     LEFT JOIN categorias c ON c.id = p.categoria_id
     WHERE p.id = ? AND p.estado_aprovacao = 'aprovado'`,
    [req.params.id]
  );
  if (!rows.length) return res.status(404).json({ erro: 'Profissional não encontrada.' });

  const [servicos] = await pool.query(
    'SELECT id, nome, descricao, preco, duracao_minutos FROM servicos WHERE profissional_id = ? AND ativo = TRUE',
    [req.params.id]
  );
  const [disponibilidades] = await pool.query(
    'SELECT dia_semana, hora_inicio, hora_fim FROM disponibilidades WHERE profissional_id = ? ORDER BY dia_semana, hora_inicio',
    [req.params.id]
  );
  res.json({ ...rows[0], servicos: servicos.map(paraNumero), disponibilidades });
});

/**
 * @openapi
 * /profissionais/{id}/avaliacoes:
 *   get:
 *     summary: Lista as avaliações publicadas de uma profissional
 *     tags: [Público]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Lista de avaliações publicadas }
 */
router.get('/profissionais/:id/avaliacoes', async (req, res) => {
  const [rows] = await pool.query(
    `SELECT a.id, a.nota AS classificacao, a.comentario, a.criado_em, u.nome AS cliente_nome
     FROM avaliacoes a
     JOIN marcacoes m ON m.id = a.marcacao_id
     JOIN utilizadores u ON u.id = m.cliente_id
     WHERE m.profissional_id = ? AND a.estado = 'publicada'
     ORDER BY a.criado_em DESC`,
    [req.params.id]
  );
  res.json(rows);
});

/**
 * @openapi
 * /servicos/{id}:
 *   get:
 *     summary: Detalhe público de um serviço
 *     tags: [Público]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Detalhe do serviço }
 *       404: { description: Serviço não encontrado }
 */
router.get('/servicos/:id', async (req, res) => {
  const [rows] = await pool.query(
    `SELECT s.id, s.nome, s.descricao, s.preco, s.duracao_minutos, p.id AS profissional_id, p.nome_negocio AS profissional_nome
     FROM servicos s
     JOIN profissionais p ON p.id = s.profissional_id
     WHERE s.id = ? AND s.ativo = TRUE`,
    [req.params.id]
  );
  if (!rows.length) return res.status(404).json({ erro: 'Serviço não encontrado.' });
  res.json(paraNumero(rows[0]));
});

module.exports = router;
