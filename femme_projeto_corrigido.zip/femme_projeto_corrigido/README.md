# Femme — Projeto completo

Marketplace de marcação de serviços de beleza.

```
femme_schema.sql   → script de criação da base de dados MySQL
backend/           → API Node.js/Express
frontend/           → site estático (HTML/JS/Bootstrap)
```

## 1. Base de dados

```bash
mysql -u root -p --default-character-set=utf8mb4 < femme_schema.sql
```
⚠️ O `--default-character-set=utf8mb4` é obrigatório — sem isto os acentos ficam corrompidos.

## 2. Backend

```bash
cd backend
cp .env.example .env    # edita DB_USER / DB_PASSWORD / JWT_SECRET / SMTP (opcional)
npm install
npm start
```
- API em `http://localhost:3000/api` · Swagger em `http://localhost:3000/api-docs`

## 3. Frontend

```bash
cd frontend
python -m http.server 8080
```
Abre `http://localhost:8080/index.html`.

## Contas de demonstração

| Email | Password | Tipo |
|---|---|---|
| admin@femme.pt | admin123 | admin |
| ines.marques@femme.pt | profissional123 | profissional (aprovada, já com horário) |
| rita.esteves@femme.pt | profissional123 | profissional (pendente) |
| ana.costa@gmail.com | cliente123 | cliente |

---

## Alterações desta ronda

### 1. Revisão estética completa
Mantive a paleta de cores original (bordô `#7A2436`, verde-azeitona `#6B7A5E`, dourado `#C9A227`, fundo creme) mas o `css/style.css` foi reescrito de raiz para dar mais profundidade e personalidade:
- **Fundo com gradientes radiais subtis** (bordô/dourado) em vez de cor lisa.
- **Hero de boas-vindas** na página "Descobrir" (`index.html`), com o eyebrow "Femme · Beleza & Bem-estar".
- **Navbar fixa** (sticky) com efeito de vidro fosco (blur) e sublinhado animado nos links.
- **Cartões com hover**: elevam-se e ganham sombra ao passar o rato; barra de destaque em gradiente no topo.
- **Botões com profundidade**: sombra, elevação ao hover, gradiente no `btn-gold`.
- **Chips de categoria, badges, estrelas de avaliação e bolhas de chat** com mais definição visual.
- **Estados vazios estilizados** (ex.: "nenhum resultado") com ícone e moldura tracejada, em vez de texto simples.
- Escala de sombras/raios consistente (`--shadow-sm/md/lg`, `--radius`) para tudo ficar coerente.
- Pequenos ajustes de responsividade na navbar em ecrãs estreitos.

Não refiz a estrutura de todas as páginas uma a uma — a maior parte do impacto vem do CSS global, que se aplica automaticamente a todos os cartões, botões e navbars já existentes. Dei atenção extra ao `index.html` por ser a primeira impressão.

### 2. Botão "Sair" movido para o perfil
Como pediste, o "Sair" deixou de estar disponível em todas as páginas e passou a viver só na página de perfil:
- **Cliente** → `conta.html`, num cartão "Sessão" com botão "Terminar sessão".
- **Profissional** → `profissional/pagina.html`, no mesmo formato.
- Removido de todas as outras páginas do cliente e da profissional (ficou só "Olá, {nome}" na navbar).
- O admin manteve o comportamento antigo (não foi pedido para mudar).

### 3. Bugs encontrados e corrigidos
- **URLs do backend escritos à mão** (`http://localhost:3000`) em 4 páginas (`index.html`, `perfil.html`, `favoritos.html`, `profissional/pagina.html`) para mostrar imagens — agora usam uma constante partilhada `UPLOADS_BASE` no `js/api.js`, derivada de `API_BASE`. Isto significa que só precisas de mudar o endereço da API num sítio quando fores para produção.
- **Referência partida no `perfil.html`**: ao remover o botão de sair da navbar, sobrou uma linha a tentar ligar um `onclick` a um elemento que deixou de existir (`getElementById("logoutLink")` retornava `null`), o que ia rebentar a página sempre que um cliente com sessão iniciada visitasse o perfil de uma profissional. Corrigido.

## Funcionalidades (recapitulando o que já existia)
Autenticação, pesquisa com filtro por localização, marcações com validação de horários (sem passado, sem conflitos, respeita disponibilidade/bloqueios), mensagens, favoritos, notificações (in-app + email), avaliações moderadas, área da profissional completa (agenda semanal, pedidos, horários, avaliações, personalização com foto/banner), área de admin, documentação Swagger.

## Notas para produção
- Gera um `JWT_SECRET` novo e não o partilhes/comites no Git.
- Configura um SMTP real para os emails saírem de facto.
- A pasta `uploads/` fica em disco local — usa disco persistente ou um bucket em produção.

## Por fazer / limitações conhecidas
- A revisão estética foi feita principalmente via CSS global; não passei página a página a redesenhar cada layout individualmente. Se houver uma página específica que ainda pareça "simples", diz-me qual e refino-a.
- Continua sem ser possível reagendar uma marcação existente (só cancelar).
